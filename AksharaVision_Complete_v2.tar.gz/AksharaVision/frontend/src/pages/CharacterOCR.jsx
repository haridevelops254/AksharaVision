import React, { useState } from 'react'
import { predictCharacter, saveCharacterFeedback } from '../api/client'
import UploadBox from '../components/UploadBox'
import PredictionCard from '../components/PredictionCard'
import FeedbackForm from '../components/FeedbackForm'

export default function CharacterOCR() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [predictions, setPredictions] = useState(null)
  const [loading, setLoading] = useState(false)
  const [feedback, setFeedback] = useState('')

  const handleFileSelect = (selectedFile) => {
    setFile(selectedFile)
    setPreview(URL.createObjectURL(selectedFile))
    setPredictions(null)
  }

  const handlePredict = async () => {
    if (!file) return
    setLoading(true)
    try {
      const result = await predictCharacter(file, 3)
      setPredictions(result.predictions)
    } catch (err) {
      alert('Prediction failed: ' + err.message)
    }
    setLoading(false)
  }

  const handleFeedback = async (correctLabel) => {
    if (!file || !predictions) return
    try {
      await saveCharacterFeedback(file, correctLabel, predictions)
      setFeedback('✓ Feedback saved!')
      setTimeout(() => setFeedback(''), 3000)
    } catch (err) {
      alert('Failed to save feedback')
    }
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">Upload Character Image</h2>
          <UploadBox onFileSelect={handleFileSelect} />
          {preview && (
            <div className="mt-4">
              <img src={preview} alt="Preview" className="max-w-full h-auto border rounded" />
              <button
                onClick={handlePredict}
                disabled={loading}
                className="mt-4 w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 disabled:bg-gray-400"
              >
                {loading ? 'Predicting...' : '🔍 Predict'}
              </button>
            </div>
          )}
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Predictions</h2>
          {predictions ? (
            <div className="space-y-4">
              {predictions.map((pred, idx) => (
                <PredictionCard key={idx} rank={idx + 1} prediction={pred} />
              ))}
            </div>
          ) : (
            <p className="text-gray-500">Upload and predict to see results</p>
          )}
        </div>
      </div>

      {predictions && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Provide Feedback</h2>
          <FeedbackForm predictions={predictions} onSubmit={handleFeedback} />
          {feedback && <p className="mt-2 text-green-600">{feedback}</p>}
        </div>
      )}
    </div>
  )
}
