import React, { useState } from 'react'
import { segmentWord, saveSegmentationFeedback } from '../api/client'
import UploadBox from '../components/UploadBox'

export default function WordOCR() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [manualWord, setManualWord] = useState('')
  const [feedback, setFeedback] = useState('')

  const handleFileSelect = (selectedFile) => {
    setFile(selectedFile)
    setPreview(URL.createObjectURL(selectedFile))
    setResults(null)
  }

  const handleSegment = async () => {
    if (!file) return
    setLoading(true)
    try {
      const result = await segmentWord(file, 2, 5)
      setResults(result.results)
    } catch (err) {
      alert('Segmentation failed: ' + err.message)
    }
    setLoading(false)
  }

  const handleSaveFeedback = async (split) => {
    if (!file || !results) return
    const result = results.find(r => r.split === split)
    const word = manualWord || result.predicted_word
    try {
      await saveSegmentationFeedback(file, split, word)
      setFeedback('✓ Feedback saved!')
      setTimeout(() => setFeedback(''), 3000)
    } catch (err) {
      alert('Failed to save feedback')
    }
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">Upload Word Image</h2>
          <UploadBox onFileSelect={handleFileSelect} />
          {preview && (
            <div className="mt-4">
              <img src={preview} alt="Preview" className="max-w-full h-auto border rounded" />
              <button
                onClick={handleSegment}
                disabled={loading}
                className="mt-4 w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600"
              >
                {loading ? 'Segmenting...' : '🧩 Segment Word'}
              </button>
            </div>
          )}
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Segmentation Results</h2>
          {results ? (
            <div className="space-y-4">
              {results.map(r => (
                <div key={r.split} className="bg-green-50 p-4 rounded border">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-semibold">Split={r.split}:</span>
                      <span className="ml-2 text-2xl">{r.predicted_word}</span>
                    </div>
                    <button
                      onClick={() => handleSaveFeedback(r.split)}
                      className="bg-green-500 text-white px-3 py-1 rounded text-sm"
                    >
                      Save
                    </button>
                  </div>
                </div>
              ))}
              <input
                type="text"
                placeholder="Manual override (optional)"
                value={manualWord}
                onChange={(e) => setManualWord(e.target.value)}
                className="w-full p-2 border rounded"
              />
              {feedback && <p className="text-green-600">{feedback}</p>}
            </div>
          ) : (
            <p className="text-gray-500">Upload and segment to see results</p>
          )}
        </div>
      </div>
    </div>
  )
}
