import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api'

export const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'multipart/form-data'
  }
})

export const predictCharacter = async (file, topk = 3) => {
  const formData = new FormData()
  formData.append('file', file)
  const response = await api.post(`/ocr/predict?topk=${topk}`, formData)
  return response.data
}

export const segmentWord = async (file, minSplits = 2, maxSplits = 5) => {
  const formData = new FormData()
  formData.append('file', file)
  const response = await api.post(
    `/segmentation/segment?min_splits=${minSplits}&max_splits=${maxSplits}`,
    formData
  )
  return response.data
}

export const saveCharacterFeedback = async (file, correctLabel, predictions) => {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('correct_label', correctLabel)
  if (predictions[0]) formData.append('top1_label', predictions[0].label)
  if (predictions[1]) formData.append('top2_label', predictions[1].label)
  if (predictions[2]) formData.append('top3_label', predictions[2].label)
  const response = await api.post('/feedback/character', formData)
  return response.data
}

export const saveSegmentationFeedback = async (file, chosenSplit, chosenWord) => {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('chosen_split', chosenSplit)
  formData.append('chosen_word', chosenWord)
  const response = await api.post('/feedback/segmentation', formData)
  return response.data
}
