import React, { useState } from 'react'
import CharacterOCR from './pages/CharacterOCR'
import WordOCR from './pages/WordOCR'

function App() {
  const [activeTab, setActiveTab] = useState('character')

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-gray-900">🪶 AksharaVision</h1>
          <p className="text-gray-600">Kannada Handwritten OCR System</p>
        </div>
      </header>

      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('character')}
              className={`py-4 px-3 border-b-2 font-medium text-sm ${
                activeTab === 'character'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              🔤 Character Recognition
            </button>
            <button
              onClick={() => setActiveTab('word')}
              className={`py-4 px-3 border-b-2 font-medium text-sm ${
                activeTab === 'word'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              📝 Word Recognition
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'character' ? <CharacterOCR /> : <WordOCR />}
      </main>

      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center text-gray-500 text-sm">
          Built with ❤️ for Kannada language preservation
        </div>
      </footer>
    </div>
  )
}

export default App
