import React, { useState } from 'react'

export default function FeedbackForm({ predictions, onSubmit }) {
  const [choice, setChoice] = useState('top1')
  const [manual, setManual] = useState('')

  const handleSubmit = () => {
    if (choice === 'manual') {
      onSubmit(manual)
    } else if (choice === 'top1') {
      onSubmit(predictions[0]?.label)
    } else if (choice === 'top2') {
      onSubmit(predictions[1]?.label)
    } else if (choice === 'top3') {
      onSubmit(predictions[2]?.label)
    }
  }

  return (
    <div className="bg-white p-6 rounded-lg border space-y-4">
      <div className="space-y-2">
        <label className="flex items-center space-x-2">
          <input
            type="radio"
            value="top1"
            checked={choice === 'top1'}
            onChange={(e) => setChoice(e.target.value)}
          />
          <span>Top-1 is correct</span>
        </label>
        <label className="flex items-center space-x-2">
          <input
            type="radio"
            value="top2"
            checked={choice === 'top2'}
            onChange={(e) => setChoice(e.target.value)}
          />
          <span>Top-2 is correct</span>
        </label>
        <label className="flex items-center space-x-2">
          <input
            type="radio"
            value="top3"
            checked={choice === 'top3'}
            onChange={(e) => setChoice(e.target.value)}
          />
          <span>Top-3 is correct</span>
        </label>
        <label className="flex items-center space-x-2">
          <input
            type="radio"
            value="manual"
            checked={choice === 'manual'}
            onChange={(e) => setChoice(e.target.value)}
          />
          <span>Manual correction</span>
        </label>
      </div>
      
      {choice === 'manual' && (
        <input
          type="text"
          placeholder="Enter correct character"
          value={manual}
          onChange={(e) => setManual(e.target.value)}
          className="w-full p-2 border rounded"
        />
      )}
      
      <button
        onClick={handleSubmit}
        className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600"
      >
        💾 Save Feedback
      </button>
    </div>
  )
}
