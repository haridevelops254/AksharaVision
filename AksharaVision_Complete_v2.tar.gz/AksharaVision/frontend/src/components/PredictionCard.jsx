import React from 'react'

export default function PredictionCard({ rank, prediction }) {
  const bgColors = ['bg-orange-50', 'bg-yellow-50', 'bg-blue-50']
  
  return (
    <div className={`${bgColors[rank - 1] || 'bg-gray-50'} p-4 rounded-lg border`}>
      <div className="flex justify-between items-center">
        <div>
          <span className="text-sm text-gray-600">Top-{rank}</span>
          <div className="text-3xl font-bold mt-1">{prediction.char}</div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-semibold text-gray-700">
            {(prediction.confidence * 100).toFixed(1)}%
          </div>
          <div className="text-xs text-gray-500">{prediction.label}</div>
        </div>
      </div>
    </div>
  )
}
