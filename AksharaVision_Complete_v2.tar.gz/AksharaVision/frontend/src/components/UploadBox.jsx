import React from 'react'

export default function UploadBox({ onFileSelect }) {
  const handleChange = (e) => {
    const file = e.target.files[0]
    if (file) onFileSelect(file)
  }

  return (
    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
      <input
        type="file"
        accept="image/*"
        onChange={handleChange}
        className="hidden"
        id="file-upload"
      />
      <label htmlFor="file-upload" className="cursor-pointer">
        <div className="text-gray-600">
          <p className="text-lg">Click to upload image</p>
          <p className="text-sm text-gray-400 mt-2">PNG, JPG (max 10MB)</p>
        </div>
      </label>
    </div>
  )
}
