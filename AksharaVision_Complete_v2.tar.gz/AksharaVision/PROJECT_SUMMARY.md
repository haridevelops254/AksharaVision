# 🪶 AksharaVision - Complete Project Summary

## 📋 Overview

**AksharaVision** is a production-ready Kannada handwritten OCR system with:
- Character-level recognition (113 classes)
- Word segmentation with progressive splitting
- Human-in-the-loop feedback for continuous improvement
- Automated retraining pipeline (triggers after 10,000 feedback entries)
- Full-stack web application (FastAPI + React)
- PostgreSQL database with BYTEA image storage
- Ready for deployment on Render, Railway, or Docker

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    React Frontend                        │
│              (Character & Word OCR UI)                   │
└─────────────────┬───────────────────────────────────────┘
                  │ HTTP/REST API
┌─────────────────▼───────────────────────────────────────┐
│              FastAPI Backend                             │
│  ┌─────────────────────────────────────────────────┐   │
│  │  API Layer (OCR, Segmentation, Feedback)       │   │
│  └─────────────────┬───────────────────────────────┘   │
│  ┌─────────────────▼───────────────────────────────┐   │
│  │  Services (Centroid, Feedback, Logging)        │   │
│  └─────────────────┬───────────────────────────────┘   │
│  ┌─────────────────▼───────────────────────────────┐   │
│  │  Inference (CharacterPredictor, WordSegmenter)  │   │
│  └─────────────────┬───────────────────────────────┘   │
│  ┌─────────────────▼───────────────────────────────┐   │
│  │  ML Model (Swin Transformer + Custom Head)     │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────┬───────────────────────────────────────┘
                  │ SQLAlchemy ORM
┌─────────────────▼───────────────────────────────────────┐
│                PostgreSQL Database                       │
│  • inference_logs (all predictions)                     │
│  • character_feedback (user corrections + images)       │
│  • segmentation_feedback (word corrections + images)    │
│  • model_versions (retraining history)                  │
└─────────────────────────────────────────────────────────┘
```

## 📂 Project Structure

```
AksharaVision/
├── README.md                   # Main documentation
├── QUICKSTART.md               # 5-minute setup guide
├── DEPLOYMENT.md               # Production deployment guide
├── DEPLOYMENT_CHECKLIST.md     # Step-by-step checklist
├── CONTRIBUTING.md             # Contribution guidelines
├── LICENSE                     # MIT License
│
├── backend/                    # FastAPI Backend
│   ├── app/
│   │   ├── main.py            # Application entry point
│   │   ├── config.py          # Configuration management
│   │   ├── startup.py         # Model/service initialization
│   │   │
│   │   ├── api/               # REST API routes
│   │   │   ├── ocr.py         # Character OCR endpoints
│   │   │   ├── segmentation.py # Word segmentation endpoints
│   │   │   └── feedback.py    # Feedback endpoints
│   │   │
│   │   ├── models/            # ML model definitions
│   │   │   └── kannada_model.py # Swin Transformer model
│   │   │
│   │   ├── inference/         # Prediction pipelines
│   │   │   ├── predict.py     # Character prediction
│   │   │   └── segmentation.py # Word segmentation
│   │   │
│   │   ├── services/          # Business logic layer
│   │   │   ├── centroid_lookup.py # Neighbor refinement
│   │   │   ├── feedback_service.py # Feedback management
│   │   │   └── logging_service.py # Inference logging
│   │   │
│   │   ├── db/                # Database layer
│   │   │   ├── base.py        # SQLAlchemy Base
│   │   │   ├── models.py      # ORM models (tables)
│   │   │   ├── session.py     # DB connection
│   │   │   └── dependencies.py # FastAPI dependencies
│   │   │
│   │   └── utils/             # Utility functions
│   │       └── image_utils.py
│   │
│   ├── project_files/         # Model checkpoints (🔴 ADD YOUR MODEL HERE)
│   │   ├── kannada_classifier_finetuned_full.pth
│   │   └── classes_list_113_kannada.json
│   │
│   ├── diagnostics/           # Analysis files
│   │   └── centroid_top3_neighbors.csv
│   │
│   ├── training/              # Retraining pipeline
│   │   ├── dataset_builder.py
│   │   └── trainer.py
│   │
│   ├── jobs/                  # Scheduled tasks
│   │   └── retrain_trigger.py # Auto-retraining check
│   │
│   ├── scripts/               # Utility scripts
│   │   ├── init_db.sql        # Manual DB initialization
│   │   └── migrate_tinydb_to_pg.py
│   │
│   ├── alembic/               # Database migrations
│   │   ├── versions/
│   │   │   └── 001_initial.py
│   │   ├── env.py
│   │   └── script.py.mako
│   │
│   ├── requirements.txt       # Python dependencies
│   ├── .env.example           # Environment template
│   ├── alembic.ini           # Alembic config
│   └── README.md
│
├── frontend/                  # React Frontend
│   ├── src/
│   │   ├── main.jsx          # App entry point
│   │   ├── App.jsx           # Main component
│   │   │
│   │   ├── pages/            # Page components
│   │   │   ├── CharacterOCR.jsx
│   │   │   └── WordOCR.jsx
│   │   │
│   │   ├── components/       # Reusable UI components
│   │   │   ├── UploadBox.jsx
│   │   │   ├── PredictionCard.jsx
│   │   │   └── FeedbackForm.jsx
│   │   │
│   │   ├── api/              # API client
│   │   │   └── client.js
│   │   │
│   │   └── index.css         # Tailwind styles
│   │
│   ├── public/
│   ├── index.html
│   ├── package.json          # Dependencies
│   ├── vite.config.js        # Vite configuration
│   ├── tailwind.config.js    # Tailwind configuration
│   └── README.md
│
├── docker/                    # Docker deployment
│   ├── backend.Dockerfile
│   ├── frontend.Dockerfile
│   └── docker-compose.yml
│
└── tests/                     # Test suite
    ├── test_ocr.py
    ├── test_segmentation.py
    └── conftest.py
```

## 🔑 Key Features

### 1. **Character Recognition**
- Swin Transformer backbone (pretrained on ImageNet)
- Custom 512-dim embedding head
- Top-3 predictions with confidence scores
- Centroid-based refinement for edge cases
- ~50-200ms inference time (GPU) / ~500-1000ms (CPU)

### 2. **Word Segmentation**
- Progressive splitting (2-5 characters)
- Character-level prediction per segment
- Multiple word hypotheses presented to user
- Manual override option

### 3. **Feedback Loop**
- Images stored as BYTEA in PostgreSQL (not file paths!)
- Character-level corrections
- Word-level corrections
- Tracks usage for retraining

### 4. **Automated Retraining**
- Triggers after 10,000 new feedback entries
- Builds dataset from PostgreSQL feedback
- Fine-tunes model on corrected data
- Hot-reloads new model without downtime

### 5. **Production-Ready**
- FastAPI with automatic OpenAPI docs
- React with Vite (fast HMR)
- PostgreSQL with SQLAlchemy ORM
- Alembic migrations for schema evolution
- Docker support
- Render/Railway deployment ready
- CORS configured
- Health check endpoints
- Comprehensive logging

## 🚀 Quick Start

### Local Development (5 minutes)
```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with DATABASE_URL
alembic upgrade head
uvicorn app.main:app --reload

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

Visit: http://localhost:5173

### Docker (1 command)
```bash
docker-compose -f docker/docker-compose.yml up --build
```

## 📊 Database Schema

### `inference_logs`
Stores all predictions for analytics
- Columns: image_data (BYTEA), top1/2/3_label, top1/2/3_conf, inference_time_ms, created_at
- Indexed: top1_label, created_at

### `character_feedback`
User corrections with images
- Columns: image_data (BYTEA), correct_label, top1/2/3_label, used_for_training, created_at
- Indexed: correct_label, used_for_training, created_at
- **Critical for retraining**

### `segmentation_feedback`
Word segmentation corrections
- Columns: image_data (BYTEA), chosen_split, chosen_word, all_splits_json, created_at
- Indexed: used_for_training, created_at

### `model_versions`
Tracks model evolution
- Columns: version, model_path, training_accuracy, is_active, deployed_at

## 🔄 Retraining Pipeline

1. **Feedback Collection**: Users correct predictions via UI
2. **Storage**: Images + corrections stored in PostgreSQL (BYTEA)
3. **Trigger Check**: Job runs daily, checks if feedback_count >= 10,000
4. **Dataset Build**: Unused feedback exported to PyTorch Dataset
5. **Training**: Fine-tune model on new data
6. **Evaluation**: Validate on holdout set
7. **Deployment**: Save new checkpoint, hot-reload model
8. **Marking**: Mark feedback as used_for_training = True

## 🌐 API Endpoints

### Character OCR
```
POST /api/ocr/predict
Body: multipart/form-data with 'file'
Query: topk=3, use_refinement=true
Response: {predictions: [{label, char, confidence}]}
```

### Word Segmentation
```
POST /api/segmentation/segment
Body: multipart/form-data with 'file'
Query: min_splits=2, max_splits=5
Response: {results: [{split, predicted_word, segments}]}
```

### Feedback
```
POST /api/feedback/character
Body: file, correct_label, top1_label, etc.

POST /api/feedback/segmentation
Body: file, chosen_split, chosen_word

GET /api/feedback/stats
Response: {character_feedback: {total, unused, used}, ...}
```

## 🔒 Security Features

- Environment-based configuration (no hardcoded secrets)
- SQL injection protection (SQLAlchemy ORM)
- File upload validation
- CORS configuration
- Optional JWT authentication (users table ready)
- HTTPS in production (automatic on Render/Railway)

## 📈 Performance Optimization

- Model loaded once at startup (singleton)
- Database connection pooling
- Indexed queries
- Image preprocessing cached transforms
- Batch prediction support
- Optional GPU acceleration

## 🧪 Testing

```bash
# Backend
cd backend
pytest

# Frontend
cd frontend
npm test

# API testing
curl http://localhost:8000/health
```

## 📦 Deployment Options

### 1. **Render.com** (Recommended for beginners)
- ✅ Free tier available
- ✅ Automatic HTTPS
- ✅ PostgreSQL included
- Time: ~15 minutes

### 2. **Railway.app** (Recommended for developers)
- ✅ Best developer experience
- ✅ Auto-detects configuration
- ✅ CLI tools
- Time: ~10 minutes

### 3. **Docker** (Self-hosted)
- ✅ Full control
- ✅ Any cloud provider (AWS, GCP, Azure, DigitalOcean)
- Time: ~20 minutes

See `DEPLOYMENT.md` for detailed instructions.

## 🎓 Next Steps After Deployment

1. **Add Your Model**: Place trained .pth file in `backend/project_files/`
2. **Test End-to-End**: Upload test images, verify predictions
3. **Collect Feedback**: Use feedback feature actively
4. **Monitor Performance**: Check logs and health endpoints
5. **Plan Retraining**: Set up cron job for retraining trigger
6. **Scale**: Add more instances, GPU inference, caching

## 🔧 Configuration

All configuration via environment variables (`.env` file):

```bash
# Database
DATABASE_URL=postgresql://user:pass@host:5432/dbname

# Model
MODEL_PATH=project_files/kannada_classifier_finetuned_full.pth
CLASSES_PATH=project_files/classes_list_113_kannada.json
CENTROID_PATH=diagnostics/centroid_top3_neighbors.csv
DEVICE=cuda  # or 'cpu'

# Application
DEBUG=False
CORS_ORIGINS=https://yourfrontend.com
FEEDBACK_THRESHOLD=10000
```

## 📚 Documentation

- **Quick Start**: `QUICKSTART.md`
- **Full Deployment**: `DEPLOYMENT.md`
- **Deployment Checklist**: `DEPLOYMENT_CHECKLIST.md`
- **Contributing**: `CONTRIBUTING.md`
- **API Docs**: http://localhost:8000/docs (Swagger UI)
- **Backend README**: `backend/README.md`

## 🐛 Troubleshooting

Common issues and solutions:

1. **Model not found**: Place .pth file in backend/project_files/ (or system runs with random weights for testing)
2. **Database connection failed**: Check DATABASE_URL, ensure PostgreSQL is running
3. **CORS error**: Add frontend URL to CORS_ORIGINS in backend/.env
4. **Port in use**: Change port in backend/app/main.py or frontend/vite.config.js

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

See `CONTRIBUTING.md` for details.

## 📄 License

MIT License - see `LICENSE` file for details.

## 🙏 Acknowledgments

- Kannada language community
- Swin Transformer (Microsoft Research)
- FastAPI framework
- React & Vite
- SQLAlchemy & Alembic

---

**Status**: ✅ Production Ready
**Version**: 1.0.0
**Last Updated**: February 4, 2026

**Built with ❤️ for Kannada language preservation and digital accessibility**
