"""
Kannada Character Classifier Model Definition
Swin Transformer backbone with custom classification head
"""
import torch
import torch.nn as nn
import timm
from typing import Tuple


class KannadaClassifier(nn.Module):
    """
    Kannada handwritten character classifier using Swin Transformer backbone
    
    Architecture:
    - Swin Tiny backbone (pretrained on ImageNet)
    - Custom embedding head (512-dim)
    - Batch normalization + ReLU + Dropout
    - Linear classifier for 113 Kannada characters
    """
    
    def __init__(
        self,
        backbone_name: str = 'swin_tiny_patch4_window7_224',
        embed_dim: int = 512,
        num_classes: int = 113,
        dropout: float = 0.35
    ):
        """
        Args:
            backbone_name: Timm model name for backbone
            embed_dim: Dimension of embedding space
            num_classes: Number of Kannada character classes
            dropout: Dropout probability
        """
        super().__init__()
        
        # Load pretrained Swin backbone
        self.backbone = timm.create_model(
            backbone_name,
            pretrained=True,
            num_classes=0,  # Remove classification head
            global_pool='avg'
        )
        
        # Get backbone feature dimension
        feat_dim = getattr(self.backbone, "num_features", None)
        if feat_dim is None:
            raise RuntimeError(
                f"Backbone {backbone_name} does not expose num_features attribute"
            )
        
        # Custom embedding head
        self.fc_embed = nn.Linear(feat_dim, embed_dim)
        self.bn = nn.BatchNorm1d(embed_dim)
        self.dropout = nn.Dropout(dropout)
        
        # Final classifier
        self.classifier = nn.Linear(embed_dim, num_classes)
        
        self.embed_dim = embed_dim
        self.num_classes = num_classes
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass
        
        Args:
            x: Input tensor of shape [B, 3, 224, 224]
        
        Returns:
            logits: Classification logits [B, num_classes]
            embeddings: Feature embeddings [B, embed_dim]
        """
        # Extract features from backbone
        features = self.backbone(x)  # [B, feat_dim]
        
        # Generate embeddings
        embeddings = self.fc_embed(features)  # [B, embed_dim]
        embeddings = self.bn(embeddings)
        embeddings = torch.relu(embeddings)
        embeddings = self.dropout(embeddings)
        
        # Classification
        logits = self.classifier(embeddings)  # [B, num_classes]
        
        return logits, embeddings
    
    def get_embeddings(self, x: torch.Tensor) -> torch.Tensor:
        """
        Extract only embeddings (useful for similarity computation)
        
        Args:
            x: Input tensor [B, 3, 224, 224]
        
        Returns:
            embeddings: [B, embed_dim]
        """
        features = self.backbone(x)
        embeddings = self.fc_embed(features)
        embeddings = self.bn(embeddings)
        embeddings = torch.relu(embeddings)
        return embeddings


def create_model(
    num_classes: int = 113,
    device: str = "cpu"
) -> KannadaClassifier:
    """
    Factory function to create model instance
    
    Args:
        num_classes: Number of output classes
        device: Device to place model on
    
    Returns:
        Initialized model on specified device
    """
    model = KannadaClassifier(
        backbone_name='swin_tiny_patch4_window7_224',
        embed_dim=512,
        num_classes=num_classes,
        dropout=0.35
    )
    model = model.to(device)
    model.eval()  # Set to evaluation mode by default
    return model


def load_checkpoint(
    model: KannadaClassifier,
    checkpoint_path: str,
    device: str = "cpu",
    strict: bool = False
) -> KannadaClassifier:
    """
    Load model weights from checkpoint with error handling
    
    Args:
        model: Model instance to load weights into
        checkpoint_path: Path to checkpoint file
        device: Device for loading
        strict: Whether to strictly enforce state dict keys match
    
    Returns:
        Model with loaded weights
    """
    import os
    
    if not os.path.exists(checkpoint_path):
        print(f"Warning: Checkpoint not found at {checkpoint_path}")
        return model
    
    try:
        # Load checkpoint
        raw_checkpoint = torch.load(checkpoint_path, map_location=device)
        
        # Handle different checkpoint formats
        if isinstance(raw_checkpoint, dict):
            if "state_dict" in raw_checkpoint:
                state_dict = raw_checkpoint["state_dict"]
            elif "model_state_dict" in raw_checkpoint:
                state_dict = raw_checkpoint["model_state_dict"]
            else:
                state_dict = raw_checkpoint
        else:
            state_dict = raw_checkpoint
        
        # Filter state dict to match model
        model_state = model.state_dict()
        filtered_state = {}
        mismatched_keys = []
        
        for key, value in state_dict.items():
            if key in model_state:
                if model_state[key].shape == value.shape:
                    filtered_state[key] = value
                else:
                    mismatched_keys.append(key)
            elif not strict:
                # Skip keys not in model if not strict
                continue
        
        # Load filtered state dict
        model.load_state_dict(filtered_state, strict=strict)
        
        print(f"✓ Loaded {len(filtered_state)}/{len(state_dict)} keys from checkpoint")
        if mismatched_keys:
            print(f"  Skipped {len(mismatched_keys)} mismatched keys")
        
        return model
        
    except Exception as e:
        print(f"Error loading checkpoint: {e}")
        return model


if __name__ == "__main__":
    # Test model creation
    model = create_model(num_classes=113, device="cpu")
    print(f"Model created successfully")
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # Test forward pass
    dummy_input = torch.randn(2, 3, 224, 224)
    logits, embeddings = model(dummy_input)
    print(f"Logits shape: {logits.shape}")
    print(f"Embeddings shape: {embeddings.shape}")
