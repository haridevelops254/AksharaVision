# Image utility functions
from PIL import Image
import numpy as np

def resize_image(image: Image.Image, size: tuple) -> Image.Image:
    return image.resize(size, Image.Resampling.LANCZOS)

def normalize_image(image: Image.Image) -> np.ndarray:
    arr = np.array(image).astype(np.float32) / 255.0
    return arr
