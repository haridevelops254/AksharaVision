"""
Character Prediction Inference Pipeline
Handles single character OCR with top-K predictions and centroid refinement
"""
import io
import time
from typing import List, Tuple, Optional, Dict
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torchvision import transforms

from app.config import settings
from app.models.kannada_model import KannadaClassifier


class CharacterPredictor:
    """
    Character-level OCR predictor with centroid-based refinement
    """
    
    def __init__(
        self,
        model: KannadaClassifier,
        classes: List[str],
        centroid_neighbors: Optional[Dict[str, List[str]]] = None,
        device: str = "cpu"
    ):
        """
        Args:
            model: Trained KannadaClassifier model
            classes: List of class labels (e.g., ['000_ಅ', '001_ಆ', ...])
            centroid_neighbors: Optional dict mapping class -> top-K neighbors
            device: Device for inference
        """
        self.model = model
        self.classes = classes
        self.centroid_neighbors = centroid_neighbors or {}
        self.device = device
        
        # Set model to eval mode
        self.model.eval()
        
        # Image preprocessing transforms
        self.transforms = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])
    
    def preprocess_image(self, image: Image.Image) -> torch.Tensor:
        """
        Preprocess PIL Image for model input
        
        Args:
            image: PIL Image (RGB)
        
        Returns:
            Preprocessed tensor [1, 3, 224, 224]
        """
        if image.mode != "RGB":
            image = image.convert("RGB")
        
        tensor = self.transforms(image).unsqueeze(0).to(self.device)
        return tensor
    
    def predict(
        self,
        image: Image.Image,
        topk: int = 3,
        use_centroid_refinement: bool = True,
        return_timing: bool = False
    ) -> Tuple[List[Dict], Optional[float]]:
        """
        Predict character from image
        
        Args:
            image: PIL Image of character
            topk: Number of top predictions to return
            use_centroid_refinement: Whether to use centroid neighbor lookup
            return_timing: Whether to return inference time
        
        Returns:
            predictions: List of dicts with keys:
                - label: Class ID (e.g., '001_ಆ')
                - char: Display character (e.g., 'ಆ')
                - confidence: Probability score (0-1)
            inference_time: Optional inference time in milliseconds
        """
        start_time = time.time()
        
        # Preprocess
        tensor = self.preprocess_image(image)
        
        # Inference
        with torch.no_grad():
            logits, embeddings = self.model(tensor)
            probs = F.softmax(logits, dim=1).cpu().numpy()[0]  # [num_classes]
        
        # Get top-K by softmax probability
        top_indices = np.argsort(-probs)[:topk]
        top_probs = probs[top_indices]
        
        # Convert to prediction format
        soft_predictions = []
        for idx, prob in zip(top_indices, top_probs):
            idx = int(idx)
            label = self.classes[idx] if idx < len(self.classes) else f"class_{idx}"
            char = label.split("_", 1)[1] if "_" in label else label
            soft_predictions.append({
                "label": label,
                "char": char,
                "confidence": float(prob)
            })
        
        # Centroid-based refinement
        if use_centroid_refinement and self.centroid_neighbors and len(soft_predictions) > 0:
            predictions = self._refine_with_centroids(soft_predictions, topk)
        else:
            predictions = soft_predictions
        
        inference_time = (time.time() - start_time) * 1000  # Convert to ms
        
        if return_timing:
            return predictions, inference_time
        return predictions, None
    
    def _refine_with_centroids(
        self,
        soft_predictions: List[Dict],
        topk: int
    ) -> List[Dict]:
        """
        Refine top-K predictions using precomputed centroid neighbors
        
        Strategy:
        1. Keep top-1 prediction
        2. Add its centroid neighbors
        3. Fill remaining slots with soft predictions
        
        Args:
            soft_predictions: Initial softmax-based predictions
            topk: Number of predictions to return
        
        Returns:
            Refined predictions list
        """
        if not soft_predictions:
            return []
        
        top1_label = soft_predictions[0]["label"]
        neighbors = self.centroid_neighbors.get(top1_label, [])
        
        # Start with top-1
        refined = [soft_predictions[0]]
        
        # Add centroid neighbors
        for neighbor_label in neighbors:
            if neighbor_label in self.classes:
                char = neighbor_label.split("_", 1)[1] if "_" in neighbor_label else neighbor_label
                refined.append({
                    "label": neighbor_label,
                    "char": char,
                    "confidence": 0.0  # Placeholder (could use embedding similarity)
                })
            if len(refined) >= topk:
                break
        
        # Fill remaining with soft predictions
        if len(refined) < topk:
            for pred in soft_predictions[1:]:
                if pred["label"] not in [r["label"] for r in refined]:
                    refined.append(pred)
                if len(refined) >= topk:
                    break
        
        return refined[:topk]
    
    def predict_batch(
        self,
        images: List[Image.Image],
        topk: int = 3,
        use_centroid_refinement: bool = True
    ) -> List[List[Dict]]:
        """
        Batch prediction for multiple images
        
        Args:
            images: List of PIL Images
            topk: Number of top predictions per image
            use_centroid_refinement: Whether to use centroid refinement
        
        Returns:
            List of prediction lists (one per image)
        """
        results = []
        for img in images:
            preds, _ = self.predict(
                img,
                topk=topk,
                use_centroid_refinement=use_centroid_refinement
            )
            results.append(preds)
        return results


def image_to_bytes(image: Image.Image, format: str = "PNG") -> bytes:
    """
    Convert PIL Image to bytes for database storage
    
    Args:
        image: PIL Image
        format: Image format (PNG, JPEG, etc.)
    
    Returns:
        Image as bytes
    """
    buffer = io.BytesIO()
    image.save(buffer, format=format)
    return buffer.getvalue()


def bytes_to_image(image_bytes: bytes) -> Image.Image:
    """
    Convert bytes to PIL Image
    
    Args:
        image_bytes: Image data as bytes
    
    Returns:
        PIL Image
    """
    buffer = io.BytesIO(image_bytes)
    return Image.open(buffer)
