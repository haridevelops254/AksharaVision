"""
Word Segmentation Inference Pipeline
Progressive segmentation with character-level prediction
"""
from typing import List, Dict, Tuple
import numpy as np
from PIL import Image

from app.inference.predict import CharacterPredictor


class WordSegmenter:
    """
    Progressive word segmentation engine
    Tries multiple split counts and predicts characters for each segment
    """
    
    def __init__(self, character_predictor: CharacterPredictor):
        """
        Args:
            character_predictor: CharacterPredictor instance for segment classification
        """
        self.predictor = character_predictor
    
    def segment_word(
        self,
        image: Image.Image,
        min_splits: int = 2,
        max_splits: int = 5,
        topk_per_segment: int = 3
    ) -> Tuple[List[Dict], str]:
        """
        Progressive word segmentation
        
        Args:
            image: PIL Image of word
            min_splits: Minimum number of character splits
            max_splits: Maximum number of character splits
            topk_per_segment: Top-K predictions per character segment
        
        Returns:
            results: List of segmentation results, each containing:
                - split: Number of splits
                - predicted_word: Merged word from top-1 predictions
                - segments: List of segment predictions
            log_text: Human-readable log
        """
        if image.mode != "RGB":
            image = image.convert("RGB")
        
        img_array = np.array(image)
        height, width, _ = img_array.shape
        
        results = []
        log_lines = [f"Progressive segmentation — image {width}x{height}\n"]
        
        for num_splits in range(min_splits, max_splits + 1):
            segment_width = width // num_splits
            segments_data = []
            predicted_chars = []
            
            for segment_idx in range(num_splits):
                # Calculate segment boundaries
                x1 = segment_idx * segment_width
                x2 = (segment_idx + 1) * segment_width if segment_idx < num_splits - 1 else width
                
                # Crop segment
                segment_crop = img_array[:, x1:x2]
                segment_pil = Image.fromarray(segment_crop)
                
                # Predict character
                predictions, _ = self.predictor.predict(
                    segment_pil,
                    topk=topk_per_segment,
                    use_centroid_refinement=True
                )
                
                # Store segment data
                segments_data.append({
                    "segment_index": segment_idx,
                    "x_start": int(x1),
                    "x_end": int(x2),
                    "top3": predictions
                })
                
                # Use top-1 for word formation
                top1_char = predictions[0]["char"] if predictions else ""
                predicted_chars.append(top1_char)
            
            # Merge characters into word
            predicted_word = "".join(predicted_chars)
            
            # Store result
            results.append({
                "split": num_splits,
                "predicted_word": predicted_word,
                "segments": segments_data
            })
            
            log_lines.append(f"Split={num_splits} → {predicted_word}")
        
        log_text = "\n".join(log_lines)
        log_text += "\n\nSelect the split you think is correct (or manually type correct word)."
        
        return results, log_text
    
    def segment_with_confidence_threshold(
        self,
        image: Image.Image,
        confidence_threshold: float = 0.8,
        max_splits: int = 5
    ) -> Dict:
        """
        Segment word using confidence-based stopping criterion
        
        Args:
            image: PIL Image of word
            confidence_threshold: Stop if average confidence exceeds this
            max_splits: Maximum number of splits to try
        
        Returns:
            Best segmentation result based on confidence
        """
        results, _ = self.segment_word(image, min_splits=2, max_splits=max_splits)
        
        best_result = None
        best_avg_confidence = 0.0
        
        for result in results:
            confidences = []
            for seg in result["segments"]:
                top1_conf = seg["top3"][0]["confidence"] if seg["top3"] else 0.0
                confidences.append(top1_conf)
            
            avg_conf = np.mean(confidences) if confidences else 0.0
            
            if avg_conf > best_avg_confidence:
                best_avg_confidence = avg_conf
                best_result = result
            
            # Early stopping if confidence exceeds threshold
            if avg_conf >= confidence_threshold:
                break
        
        if best_result:
            best_result["average_confidence"] = float(best_avg_confidence)
        
        return best_result or results[0] if results else None
    
    def visualize_segmentation(
        self,
        image: Image.Image,
        segmentation_result: Dict
    ) -> Image.Image:
        """
        Draw segmentation boundaries on image
        
        Args:
            image: Original PIL Image
            segmentation_result: Result dict from segment_word
        
        Returns:
            PIL Image with segmentation lines drawn
        """
        from PIL import ImageDraw
        
        img_copy = image.copy().convert("RGB")
        draw = ImageDraw.Draw(img_copy)
        
        segments = segmentation_result.get("segments", [])
        for seg in segments:
            x_start = seg["x_start"]
            x_end = seg["x_end"]
            
            # Draw vertical line at segment boundary
            if x_end < img_copy.width:
                draw.line(
                    [(x_end, 0), (x_end, img_copy.height)],
                    fill="red",
                    width=2
                )
            
            # Optionally draw predicted character
            top1 = seg["top3"][0] if seg["top3"] else None
            if top1:
                char = top1["char"]
                # Note: Drawing text requires font, skipping for simplicity
                # Could add: draw.text((x_start + 5, 5), char, fill="blue")
        
        return img_copy


def merge_segments_to_word(segments: List[Dict], topk: int = 1) -> str:
    """
    Merge segmented character predictions into word
    
    Args:
        segments: List of segment prediction dicts
        topk: Which prediction to use (1 for top-1, 2 for top-2, etc.)
    
    Returns:
        Merged word string
    """
    chars = []
    for seg in segments:
        predictions = seg.get("top3", [])
        if len(predictions) >= topk:
            char = predictions[topk - 1]["char"]
            chars.append(char)
        else:
            chars.append("?")  # Placeholder for missing predictions
    return "".join(chars)
