"""
Feedback API Routes
"""
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.orm import Session
from PIL import Image
import io
from typing import Optional

from app.db.dependencies import get_db
from app.services.feedback_service import FeedbackService

router = APIRouter()

@router.post("/character")
async def save_character_feedback(
    file: UploadFile = File(...),
    correct_label: str = Form(...),
    top1_label: Optional[str] = Form(None),
    top2_label: Optional[str] = Form(None),
    top3_label: Optional[str] = Form(None),
    feedback_type: Optional[str] = Form(None),
    user_notes: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    """
    Save character recognition feedback
    
    Args:
        file: Character image
        correct_label: User-confirmed correct label
        top1_label: Top-1 prediction (optional)
        top2_label: Top-2 prediction (optional)
        top3_label: Top-3 prediction (optional)
        feedback_type: Type of feedback
        user_notes: Optional user notes
    """
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        
        feedback = FeedbackService.save_character_feedback(
            db=db,
            image=image,
            correct_label=correct_label,
            top1_label=top1_label,
            top2_label=top2_label,
            top3_label=top3_label,
            feedback_type=feedback_type,
            user_notes=user_notes,
            image_name=file.filename
        )
        
        return {
            "success": True,
            "feedback_id": feedback.id,
            "message": "Feedback saved successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save feedback: {str(e)}")

@router.post("/segmentation")
async def save_segmentation_feedback(
    file: UploadFile = File(...),
    chosen_split: int = Form(...),
    chosen_word: str = Form(...),
    db: Session = Depends(get_db)
):
    """
    Save word segmentation feedback
    """
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        
        feedback = FeedbackService.save_segmentation_feedback(
            db=db,
            image=image,
            chosen_split=chosen_split,
            chosen_word=chosen_word,
            image_name=file.filename
        )
        
        return {
            "success": True,
            "feedback_id": feedback.id,
            "message": "Segmentation feedback saved successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save feedback: {str(e)}")

@router.get("/stats")
async def get_feedback_stats(db: Session = Depends(get_db)):
    """Get feedback statistics"""
    try:
        stats = FeedbackService.get_feedback_statistics(db)
        return {"success": True, "statistics": stats}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
