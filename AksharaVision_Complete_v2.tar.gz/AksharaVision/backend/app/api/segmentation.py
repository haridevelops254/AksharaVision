"""
Word Segmentation API Routes
"""
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from PIL import Image
import io

from app.db.dependencies import get_db
from app.startup import get_word_segmenter

router = APIRouter()

@router.post("/segment")
async def segment_word(
    file: UploadFile = File(...),
    min_splits: int = 2,
    max_splits: int = 5,
    db: Session = Depends(get_db)
):
    """
    Segment word image into characters
    
    Args:
        file: Word image file
        min_splits: Minimum number of character splits
        max_splits: Maximum number of character splits
    
    Returns:
        Segmentation results for all split counts
    """
    try:
        # Read and validate image
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        
        # Get segmenter
        segmenter = get_word_segmenter()
        
        # Perform segmentation
        results, log_text = segmenter.segment_word(
            image,
            min_splits=min_splits,
            max_splits=max_splits
        )
        
        return {
            "success": True,
            "results": results,
            "log": log_text,
            "image_width": image.width,
            "image_height": image.height
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Segmentation failed: {str(e)}")
