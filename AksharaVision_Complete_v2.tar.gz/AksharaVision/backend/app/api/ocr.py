"""
Character OCR API Routes
"""
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from PIL import Image
import io

from app.db.dependencies import get_db
from app.startup import get_character_predictor
from app.services.logging_service import LoggingService

router = APIRouter()

@router.post("/predict")
async def predict_character(
    file: UploadFile = File(...),
    topk: int = 3,
    use_refinement: bool = True,
    db: Session = Depends(get_db)
):
    """
    Predict Kannada character from image
    
    Args:
        file: Image file upload
        topk: Number of top predictions (default: 3)
        use_refinement: Use centroid refinement (default: True)
    
    Returns:
        Predictions with confidence scores
    """
    try:
        # Read and validate image
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        
        # Get predictor
        predictor = get_character_predictor()
        
        # Perform prediction
        predictions, inference_time = predictor.predict(
            image,
            topk=topk,
            use_centroid_refinement=use_refinement,
            return_timing=True
        )
        
        # Log inference
        LoggingService.log_inference(
            db=db,
            predictions=predictions,
            image=image,
            image_name=file.filename,
            inference_time_ms=inference_time
        )
        
        return {
            "success": True,
            "predictions": predictions,
            "inference_time_ms": inference_time,
            "topk": len(predictions)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")
