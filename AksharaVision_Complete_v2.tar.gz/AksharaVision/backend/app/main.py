"""
Main FastAPI Application
AksharaVision - Kannada OCR System
"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import time

from app.config import settings
from app.startup import initialize_app
from app.db.session import check_db_connection


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager
    Handles startup and shutdown events
    """
    # Startup
    print("\n" + "="*60)
    print("🪶 AksharaVision - Kannada OCR System")
    print("="*60 + "\n")
    
    # Initialize application components
    initialize_app()
    
    # Check database
    db_status = "✓ Connected" if check_db_connection() else "✗ Not connected"
    print(f"📊 Database: {db_status}")
    print(f"🌐 API Docs: http://{settings.host}:{settings.port}/docs")
    print("\n" + "="*60 + "\n")
    
    yield
    
    # Shutdown
    print("\n👋 Shutting down AksharaVision...")


# Create FastAPI app
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Production-grade Kannada handwritten character and word recognition system with human-in-the-loop feedback",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add processing time to response headers"""
    start_time = time.time()
    response = await call_next(request)
    process_time = (time.time() - start_time) * 1000  # Convert to ms
    response.headers["X-Process-Time-Ms"] = str(round(process_time, 2))
    return response


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle uncaught exceptions"""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": str(exc) if settings.debug else "An error occurred",
            "path": str(request.url)
        }
    )


# Health check endpoint
@app.get("/health")
async def health_check():
    """
    Health check endpoint for monitoring
    """
    db_healthy = check_db_connection()
    
    return {
        "status": "healthy" if db_healthy else "degraded",
        "version": settings.app_version,
        "database": "connected" if db_healthy else "disconnected"
    }


# Root endpoint
@app.get("/")
async def root():
    """
    Root endpoint with API information
    """
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "description": "Kannada OCR API with character recognition and word segmentation",
        "docs": "/docs",
        "health": "/health",
        "endpoints": {
            "character_ocr": f"{settings.api_prefix}/ocr/predict",
            "word_segmentation": f"{settings.api_prefix}/segmentation/segment",
            "character_feedback": f"{settings.api_prefix}/feedback/character",
            "segmentation_feedback": f"{settings.api_prefix}/feedback/segmentation"
        }
    }


# Import and include API routers
from app.api import ocr, segmentation, feedback

app.include_router(
    ocr.router,
    prefix=f"{settings.api_prefix}/ocr",
    tags=["Character OCR"]
)

app.include_router(
    segmentation.router,
    prefix=f"{settings.api_prefix}/segmentation",
    tags=["Word Segmentation"]
)

app.include_router(
    feedback.router,
    prefix=f"{settings.api_prefix}/feedback",
    tags=["Feedback"]
)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        workers=1 if settings.debug else settings.workers
    )
