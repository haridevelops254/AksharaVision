"""
Centroid Neighbor Lookup Service
Loads and manages centroid-based character similarity data
"""
import csv
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd


class CentroidLookupService:
    """
    Service for loading and querying centroid neighbor relationships
    """
    
    def __init__(self, csv_path: Optional[str] = None):
        """
        Args:
            csv_path: Path to centroid neighbors CSV file
        """
        self.csv_path = csv_path
        self.lookup_table: Dict[str, List[str]] = {}
        
        if csv_path and Path(csv_path).exists():
            self.load_from_csv(csv_path)
    
    def load_from_csv(self, csv_path: str) -> bool:
        """
        Load centroid neighbors from CSV
        
        CSV Format:
        class_id, neighbor1, neighbor2, neighbor3, ...
        001_a, 014_am, 033_ga, 052_ka
        ...
        
        Args:
            csv_path: Path to CSV file
        
        Returns:
            True if loaded successfully
        """
        try:
            df = pd.read_csv(csv_path, dtype=str, header=0).fillna("")
            
            for _, row in df.iterrows():
                # First column is the class ID
                class_id = str(row.iloc[0]).strip()
                
                # Remaining columns are neighbors
                neighbors = [
                    str(x).strip()
                    for x in row.iloc[1:].tolist()
                    if str(x).strip() != ""
                ]
                
                self.lookup_table[class_id] = neighbors
            
            print(f"✓ Loaded centroid lookup table with {len(self.lookup_table)} entries")
            return True
            
        except Exception as e:
            print(f"✗ Failed to load centroid neighbors from {csv_path}: {e}")
            return False
    
    def get_neighbors(
        self,
        class_id: str,
        topk: int = 3
    ) -> List[str]:
        """
        Get top-K neighbors for a class
        
        Args:
            class_id: Class identifier (e.g., '001_a')
            topk: Number of neighbors to return
        
        Returns:
            List of neighbor class IDs
        """
        neighbors = self.lookup_table.get(class_id, [])
        return neighbors[:topk]
    
    def has_neighbors(self, class_id: str) -> bool:
        """
        Check if class has neighbor data
        
        Args:
            class_id: Class identifier
        
        Returns:
            True if neighbors exist
        """
        return class_id in self.lookup_table
    
    def export_to_dict(self) -> Dict[str, List[str]]:
        """
        Export lookup table as dictionary
        
        Returns:
            Full lookup dictionary
        """
        return self.lookup_table.copy()
    
    def get_stats(self) -> Dict:
        """
        Get statistics about the lookup table
        
        Returns:
            Dict with statistics
        """
        if not self.lookup_table:
            return {
                "total_classes": 0,
                "avg_neighbors": 0,
                "max_neighbors": 0,
                "min_neighbors": 0
            }
        
        neighbor_counts = [len(neighbors) for neighbors in self.lookup_table.values()]
        
        return {
            "total_classes": len(self.lookup_table),
            "avg_neighbors": sum(neighbor_counts) / len(neighbor_counts),
            "max_neighbors": max(neighbor_counts),
            "min_neighbors": min(neighbor_counts)
        }


def load_centroid_neighbors(csv_path: str) -> Optional[Dict[str, List[str]]]:
    """
    Convenience function to load centroid neighbors
    
    Args:
        csv_path: Path to CSV file
    
    Returns:
        Lookup dictionary or None if failed
    """
    service = CentroidLookupService(csv_path)
    return service.lookup_table if service.lookup_table else None
