"""
Feedback Service
Handles saving and querying user feedback for both characters and segmentation
"""
from typing import List, Optional, Dict
from sqlalchemy.orm import Session
from datetime import datetime

from app.db.models import CharacterFeedback, SegmentationFeedback
from app.inference.predict import image_to_bytes
from PIL import Image


class FeedbackService:
    """
    Service for managing user feedback
    """
    
    @staticmethod
    def save_character_feedback(
        db: Session,
        image: Image.Image,
        correct_label: str,
        top1_label: Optional[str] = None,
        top2_label: Optional[str] = None,
        top3_label: Optional[str] = None,
        feedback_type: Optional[str] = None,
        user_notes: Optional[str] = None,
        image_name: Optional[str] = None
    ) -> CharacterFeedback:
        """
        Save character correction feedback
        
        Args:
            db: Database session
            image: PIL Image of character
            correct_label: User-confirmed correct label
            top1_label: Top-1 prediction (optional)
            top2_label: Top-2 prediction (optional)
            top3_label: Top-3 prediction (optional)
            feedback_type: Type of feedback (e.g., 'Top-1 correct', 'Manual correction')
            user_notes: Optional notes from user
            image_name: Optional original filename
        
        Returns:
            Created CharacterFeedback record
        """
        # Convert image to bytes
        image_bytes = image_to_bytes(image, format="PNG")
        
        # Create feedback record
        feedback = CharacterFeedback(
            image_data=image_bytes,
            image_name=image_name,
            image_format="png",
            top1_label=top1_label,
            top2_label=top2_label,
            top3_label=top3_label,
            correct_label=correct_label,
            feedback_type=feedback_type,
            user_notes=user_notes,
            used_for_training=False
        )
        
        db.add(feedback)
        db.commit()
        db.refresh(feedback)
        
        return feedback
    
    @staticmethod
    def save_segmentation_feedback(
        db: Session,
        image: Image.Image,
        chosen_split: int,
        chosen_word: str,
        all_splits_data: Optional[List[Dict]] = None,
        image_name: Optional[str] = None
    ) -> SegmentationFeedback:
        """
        Save word segmentation feedback
        
        Args:
            db: Database session
            image: PIL Image of word
            chosen_split: Number of splits user selected
            chosen_word: Final word user confirmed
            all_splits_data: All segmentation attempts (JSON-serializable)
            image_name: Optional original filename
        
        Returns:
            Created SegmentationFeedback record
        """
        # Convert image to bytes
        image_bytes = image_to_bytes(image, format="PNG")
        
        # Create feedback record
        feedback = SegmentationFeedback(
            image_data=image_bytes,
            image_name=image_name,
            chosen_split=chosen_split,
            chosen_word=chosen_word,
            all_splits_json=all_splits_data,
            used_for_training=False
        )
        
        db.add(feedback)
        db.commit()
        db.refresh(feedback)
        
        return feedback
    
    @staticmethod
    def get_character_feedback_count(
        db: Session,
        unused_only: bool = False
    ) -> int:
        """
        Get count of character feedback entries
        
        Args:
            db: Database session
            unused_only: If True, only count entries not yet used for training
        
        Returns:
            Count of feedback entries
        """
        query = db.query(CharacterFeedback)
        
        if unused_only:
            query = query.filter(CharacterFeedback.used_for_training == False)
        
        return query.count()
    
    @staticmethod
    def get_segmentation_feedback_count(
        db: Session,
        unused_only: bool = False
    ) -> int:
        """
        Get count of segmentation feedback entries
        
        Args:
            db: Database session
            unused_only: If True, only count entries not yet used for training
        
        Returns:
            Count of feedback entries
        """
        query = db.query(SegmentationFeedback)
        
        if unused_only:
            query = query.filter(SegmentationFeedback.used_for_training == False)
        
        return query.count()
    
    @staticmethod
    def should_trigger_retraining(
        db: Session,
        threshold: int = 10000
    ) -> bool:
        """
        Check if retraining should be triggered
        
        Args:
            db: Database session
            threshold: Feedback threshold for retraining
        
        Returns:
            True if retraining should be triggered
        """
        unused_count = FeedbackService.get_character_feedback_count(
            db,
            unused_only=True
        )
        return unused_count >= threshold
    
    @staticmethod
    def mark_feedback_as_used(
        db: Session,
        feedback_ids: List[int],
        training_batch_id: int,
        feedback_type: str = "character"
    ):
        """
        Mark feedback entries as used for training
        
        Args:
            db: Database session
            feedback_ids: List of feedback IDs to mark
            training_batch_id: ID of training batch
            feedback_type: 'character' or 'segmentation'
        """
        if feedback_type == "character":
            db.query(CharacterFeedback).filter(
                CharacterFeedback.id.in_(feedback_ids)
            ).update(
                {
                    "used_for_training": True,
                    "training_batch_id": training_batch_id
                },
                synchronize_session=False
            )
        else:
            db.query(SegmentationFeedback).filter(
                SegmentationFeedback.id.in_(feedback_ids)
            ).update(
                {
                    "used_for_training": True,
                    "training_batch_id": training_batch_id
                },
                synchronize_session=False
            )
        
        db.commit()
    
    @staticmethod
    def get_unused_feedback(
        db: Session,
        limit: Optional[int] = None,
        feedback_type: str = "character"
    ) -> List:
        """
        Get unused feedback entries for retraining
        
        Args:
            db: Database session
            limit: Optional limit on number of entries
            feedback_type: 'character' or 'segmentation'
        
        Returns:
            List of feedback records
        """
        if feedback_type == "character":
            query = db.query(CharacterFeedback).filter(
                CharacterFeedback.used_for_training == False
            )
        else:
            query = db.query(SegmentationFeedback).filter(
                SegmentationFeedback.used_for_training == False
            )
        
        if limit:
            query = query.limit(limit)
        
        return query.all()
    
    @staticmethod
    def get_feedback_statistics(db: Session) -> Dict:
        """
        Get statistics about feedback data
        
        Args:
            db: Database session
        
        Returns:
            Dictionary with statistics
        """
        total_char = db.query(CharacterFeedback).count()
        unused_char = db.query(CharacterFeedback).filter(
            CharacterFeedback.used_for_training == False
        ).count()
        
        total_seg = db.query(SegmentationFeedback).count()
        unused_seg = db.query(SegmentationFeedback).filter(
            SegmentationFeedback.used_for_training == False
        ).count()
        
        return {
            "character_feedback": {
                "total": total_char,
                "unused": unused_char,
                "used": total_char - unused_char
            },
            "segmentation_feedback": {
                "total": total_seg,
                "unused": unused_seg,
                "used": total_seg - unused_seg
            }
        }
