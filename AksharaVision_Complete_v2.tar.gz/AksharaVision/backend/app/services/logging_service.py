"""
Logging Service
Handles logging of inference results to database
"""
from typing import List, Dict, Optional
from sqlalchemy.orm import Session
from PIL import Image

from app.db.models import InferenceLog
from app.inference.predict import image_to_bytes


class LoggingService:
    """
    Service for logging inference results
    """
    
    @staticmethod
    def log_inference(
        db: Session,
        predictions: List[Dict],
        image: Optional[Image.Image] = None,
        image_name: Optional[str] = None,
        inference_time_ms: Optional[float] = None,
        model_version: str = "v1.0"
    ) -> InferenceLog:
        """
        Log inference result to database
        
        Args:
            db: Database session
            predictions: List of prediction dicts with 'label', 'char', 'confidence'
            image: Optional PIL Image to store
            image_name: Optional image name
            inference_time_ms: Inference time in milliseconds
            model_version: Model version string
        
        Returns:
            Created InferenceLog record
        """
        # Extract top-3 predictions
        top1 = predictions[0] if len(predictions) > 0 else {}
        top2 = predictions[1] if len(predictions) > 1 else {}
        top3 = predictions[2] if len(predictions) > 2 else {}
        
        # Convert image to bytes if provided
        image_data = None
        if image:
            image_data = image_to_bytes(image, format="PNG")
        
        # Create log entry
        log = InferenceLog(
            image_name=image_name,
            image_data=image_data,
            top1_label=top1.get("label"),
            top1_char=top1.get("char"),
            top1_conf=top1.get("confidence"),
            top2_label=top2.get("label"),
            top2_char=top2.get("char"),
            top2_conf=top2.get("confidence"),
            top3_label=top3.get("label"),
            top3_char=top3.get("char"),
            top3_conf=top3.get("confidence"),
            inference_time_ms=inference_time_ms,
            model_version=model_version
        )
        
        db.add(log)
        db.commit()
        db.refresh(log)
        
        return log
    
    @staticmethod
    def get_recent_logs(
        db: Session,
        limit: int = 100
    ) -> List[InferenceLog]:
        """
        Get recent inference logs
        
        Args:
            db: Database session
            limit: Number of logs to retrieve
        
        Returns:
            List of InferenceLog records
        """
        return db.query(InferenceLog)\
            .order_by(InferenceLog.created_at.desc())\
            .limit(limit)\
            .all()
    
    @staticmethod
    def get_logs_by_prediction(
        db: Session,
        predicted_label: str,
        limit: int = 50
    ) -> List[InferenceLog]:
        """
        Get logs filtered by top-1 prediction
        
        Args:
            db: Database session
            predicted_label: Label to filter by
            limit: Number of logs to retrieve
        
        Returns:
            List of InferenceLog records
        """
        return db.query(InferenceLog)\
            .filter(InferenceLog.top1_label == predicted_label)\
            .order_by(InferenceLog.created_at.desc())\
            .limit(limit)\
            .all()
