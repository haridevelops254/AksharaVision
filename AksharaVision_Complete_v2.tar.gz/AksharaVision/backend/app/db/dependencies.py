"""
Database Dependencies for FastAPI
Provides dependency injection functions
"""
from typing import Generator
from sqlalchemy.orm import Session
from app.db.session import SessionLocal


def get_db() -> Generator[Session, None, None]:
    """
    FastAPI dependency that provides database session
    
    Usage in routes:
        @router.post("/items")
        def create_item(item: Item, db: Session = Depends(get_db)):
            # Use db session here
            pass
    
    Automatically handles session lifecycle:
    - Opens session before request
    - Commits on success
    - Rolls back on error
    - Closes session after request
    """
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
