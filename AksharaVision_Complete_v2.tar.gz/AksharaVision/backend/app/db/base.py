"""
SQLAlchemy Base
Declarative base for all ORM models
"""
from sqlalchemy.ext.declarative import declarative_base

# Create declarative base
Base = declarative_base()
