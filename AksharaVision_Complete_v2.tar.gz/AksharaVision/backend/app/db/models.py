"""
Database Models (SQLAlchemy ORM)
Defines schema for PostgreSQL tables
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, LargeBinary, Float, Boolean, JSON
from sqlalchemy.sql import func
from .base import Base


class InferenceLog(Base):
    """
    Stores all inference/prediction results for analytics
    """
    __tablename__ = "inference_logs"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    # Image metadata
    image_name = Column(String(255), nullable=True)
    image_data = Column(LargeBinary, nullable=True)  # Store actual image as BYTEA
    
    # Predictions (Top-3)
    top1_label = Column(String(50), nullable=True, index=True)
    top1_char = Column(String(10), nullable=True)
    top1_conf = Column(Float, nullable=True)
    
    top2_label = Column(String(50), nullable=True)
    top2_char = Column(String(10), nullable=True)
    top2_conf = Column(Float, nullable=True)
    
    top3_label = Column(String(50), nullable=True)
    top3_char = Column(String(10), nullable=True)
    top3_conf = Column(Float, nullable=True)
    
    # Metadata
    inference_time_ms = Column(Float, nullable=True)  # Inference latency
    model_version = Column(String(50), nullable=True, default="v1.0")
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    
    def __repr__(self):
        return f"<InferenceLog {self.id}: {self.top1_char} ({self.top1_conf:.2%})>"


class CharacterFeedback(Base):
    """
    Stores user feedback/corrections for character predictions
    Critical for retraining pipeline
    """
    __tablename__ = "character_feedback"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    # Image storage (BYTEA - actual binary data)
    image_data = Column(LargeBinary, nullable=False)
    image_name = Column(String(255), nullable=True)
    image_format = Column(String(10), nullable=True, default="png")
    
    # Original predictions
    top1_label = Column(String(50), nullable=True)
    top2_label = Column(String(50), nullable=True)
    top3_label = Column(String(50), nullable=True)
    
    # User correction
    correct_label = Column(String(50), nullable=False, index=True)
    feedback_type = Column(String(50), nullable=True)  # 'Top-1 correct', 'Manual correction', etc.
    
    # Additional context
    user_notes = Column(Text, nullable=True)
    
    # Retraining metadata
    used_for_training = Column(Boolean, default=False, index=True)
    training_batch_id = Column(Integer, nullable=True, index=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    def __repr__(self):
        return f"<CharacterFeedback {self.id}: {self.correct_label}>"


class SegmentationFeedback(Base):
    """
    Stores feedback for word segmentation predictions
    """
    __tablename__ = "segmentation_feedback"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    # Image storage
    image_data = Column(LargeBinary, nullable=False)
    image_name = Column(String(255), nullable=True)
    
    # Segmentation results
    chosen_split = Column(Integer, nullable=False)  # Which split count user chose (2-5)
    chosen_word = Column(String(200), nullable=False)  # Final word user confirmed
    
    # All split attempts (JSON)
    all_splits_json = Column(JSON, nullable=True)
    
    # Retraining metadata
    used_for_training = Column(Boolean, default=False, index=True)
    training_batch_id = Column(Integer, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    def __repr__(self):
        return f"<SegmentationFeedback {self.id}: {self.chosen_word} (split={self.chosen_split})>"


class ModelVersion(Base):
    """
    Tracks model versions and retraining history
    """
    __tablename__ = "model_versions"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    version = Column(String(50), unique=True, nullable=False, index=True)  # e.g., "v1.0", "v1.1"
    model_path = Column(String(500), nullable=False)  # Path to .pth file
    
    # Training metadata
    training_feedback_count = Column(Integer, nullable=True)  # How many feedback items used
    training_accuracy = Column(Float, nullable=True)
    training_loss = Column(Float, nullable=True)
    
    # Deployment
    is_active = Column(Boolean, default=False, index=True)
    deployed_at = Column(DateTime(timezone=True), nullable=True)
    
    # Metadata
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    def __repr__(self):
        return f"<ModelVersion {self.version} {'(active)' if self.is_active else ''}>"


# Optional: User management (for future multi-user scenarios)
class User(Base):
    """
    User management (optional, for future expansion)
    """
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=True, index=True)
    hashed_password = Column(String(255), nullable=True)
    
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_login = Column(DateTime(timezone=True), nullable=True)
    
    def __repr__(self):
        return f"<User {self.username}>"
