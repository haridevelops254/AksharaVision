"""
Database Session Management
Creates and manages SQLAlchemy engine and session
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from typing import Generator
import os

from app.config import settings


# Create database engine
def get_engine():
    """
    Create SQLAlchemy engine with appropriate settings
    """
    database_url = settings.database_url
    
    # Handle SQLite for testing
    if database_url.startswith("sqlite"):
        engine = create_engine(
            database_url,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
        )
    else:
        # PostgreSQL production settings
        engine = create_engine(
            database_url,
            pool_pre_ping=True,  # Verify connections before using
            pool_size=10,
            max_overflow=20,
            echo=settings.debug,  # Log SQL in debug mode
        )
    
    return engine


# Create engine instance
engine = get_engine()

# Create session factory
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)


def get_db() -> Generator[Session, None, None]:
    """
    Dependency for FastAPI routes to get database session
    
    Usage:
        @app.get("/items")
        def read_items(db: Session = Depends(get_db)):
            return db.query(Item).all()
    
    Yields:
        Database session that is automatically closed after use
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """
    Initialize database tables
    Creates all tables defined in models.py
    
    Note: In production, use Alembic migrations instead
    """
    from app.db.base import Base
    from app.db import models  # Import models to register them
    
    Base.metadata.create_all(bind=engine)
    print("✓ Database tables created successfully")


def check_db_connection() -> bool:
    """
    Check if database connection is working
    
    Returns:
        True if connection successful, False otherwise
    """
    try:
        with engine.connect() as conn:
            conn.execute("SELECT 1")
        return True
    except Exception as e:
        print(f"✗ Database connection failed: {e}")
        return False


# Test connection on import (in debug mode)
if settings.debug:
    if check_db_connection():
        print("✓ Database connection successful")
    else:
        print("✗ Warning: Database connection failed")
