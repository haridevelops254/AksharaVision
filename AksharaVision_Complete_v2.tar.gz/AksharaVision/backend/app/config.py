"""
Configuration management for AksharaVision
Loads settings from environment variables
"""
import os
from pathlib import Path
from typing import List
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Application
    app_name: str = Field(default="AksharaVision", env="APP_NAME")
    app_version: str = Field(default="1.0.0", env="APP_VERSION")
    debug: bool = Field(default=False, env="DEBUG")
    api_prefix: str = Field(default="/api", env="API_PREFIX")
    
    # Database
    database_url: str = Field(..., env="DATABASE_URL")
    database_url_async: str = Field(default=None, env="DATABASE_URL_ASYNC")
    
    # Server
    host: str = Field(default="0.0.0.0", env="HOST")
    port: int = Field(default=8000, env="PORT")
    workers: int = Field(default=4, env="WORKERS")
    
    # CORS
    cors_origins: str = Field(
        default="http://localhost:3000,http://localhost:5173",
        env="CORS_ORIGINS"
    )
    
    @property
    def cors_origins_list(self) -> List[str]:
        """Parse CORS origins from comma-separated string"""
        return [origin.strip() for origin in self.cors_origins.split(",")]
    
    # Model Configuration
    model_path: str = Field(
        default="project_files/kannada_classifier_finetuned_full.pth",
        env="MODEL_PATH"
    )
    classes_path: str = Field(
        default="project_files/classes_list_113_kannada.json",
        env="CLASSES_PATH"
    )
    centroid_path: str = Field(
        default="diagnostics/centroid_top3_neighbors.csv",
        env="CENTROID_PATH"
    )
    device: str = Field(default="cpu", env="DEVICE")
    
    # Feedback & Retraining
    feedback_threshold: int = Field(default=10000, env="FEEDBACK_THRESHOLD")
    enable_auto_retrain: bool = Field(default=True, env="ENABLE_AUTO_RETRAIN")
    
    # File Upload
    max_upload_size: int = Field(default=10485760, env="MAX_UPLOAD_SIZE")  # 10MB
    allowed_extensions: str = Field(default="png,jpg,jpeg", env="ALLOWED_EXTENSIONS")
    
    @property
    def allowed_extensions_list(self) -> List[str]:
        """Parse allowed extensions from comma-separated string"""
        return [ext.strip() for ext in self.allowed_extensions.split(",")]
    
    # Logging
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_file: str = Field(default="logs/app.log", env="LOG_FILE")
    
    # Security
    secret_key: str = Field(default="change-me-in-production", env="SECRET_KEY")
    algorithm: str = Field(default="HS256", env="ALGORITHM")
    access_token_expire_minutes: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    
    class Config:
        env_file = ".env"
        case_sensitive = False


# Singleton instance
_settings = None


def get_settings() -> Settings:
    """Get or create settings singleton"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


# Convenience function for direct access
settings = get_settings()


# Ensure necessary directories exist
def ensure_directories():
    """Create necessary directories if they don't exist"""
    base_dir = Path(__file__).parent.parent
    dirs = [
        base_dir / "logs",
        base_dir / "project_files",
        base_dir / "project_files" / "checkpoints",
        base_dir / "diagnostics",
    ]
    for directory in dirs:
        directory.mkdir(parents=True, exist_ok=True)


# Create directories on import
ensure_directories()
