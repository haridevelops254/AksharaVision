"""
Startup Module
Initializes model, services, and database on application startup
"""
import json
from pathlib import Path
from typing import Optional, List, Dict

import torch

from app.config import settings
from app.models.kannada_model import KannadaClassifier, load_checkpoint
from app.inference.predict import CharacterPredictor
from app.inference.segmentation import WordSegmenter
from app.services.centroid_lookup import CentroidLookupService
from app.db.session import check_db_connection, init_db


class ApplicationState:
    """
    Global application state (singleton)
    Stores loaded model, predictor, and services
    """
    
    def __init__(self):
        self.model: Optional[KannadaClassifier] = None
        self.character_predictor: Optional[CharacterPredictor] = None
        self.word_segmenter: Optional[WordSegmenter] = None
        self.classes: List[str] = []
        self.centroid_service: Optional[CentroidLookupService] = None
        self.device: str = "cpu"
        self.is_initialized: bool = False
    
    def initialize(self):
        """
        Initialize all components
        Should be called on application startup
        """
        if self.is_initialized:
            print("⚠ Application already initialized")
            return
        
        print("🚀 Initializing AksharaVision...")
        
        # 1. Check database connection
        print("📊 Checking database connection...")
        if not check_db_connection():
            print("⚠ Warning: Database connection failed. Some features may not work.")
        else:
            print("✓ Database connection successful")
        
        # 2. Determine device
        self.device = settings.device
        if self.device == "cuda" and not torch.cuda.is_available():
            print("⚠ CUDA requested but not available, falling back to CPU")
            self.device = "cpu"
        print(f"🖥️ Using device: {self.device}")
        
        # 3. Load classes
        print("📚 Loading class labels...")
        self.classes = self._load_classes()
        print(f"✓ Loaded {len(self.classes)} class labels")
        
        # 4. Load centroid neighbors
        print("🎯 Loading centroid neighbors...")
        self.centroid_service = self._load_centroid_service()
        if self.centroid_service and self.centroid_service.lookup_table:
            stats = self.centroid_service.get_stats()
            print(f"✓ Loaded centroid lookup: {stats['total_classes']} classes, "
                  f"avg {stats['avg_neighbors']:.1f} neighbors")
        else:
            print("⚠ Centroid neighbors not loaded (will use softmax-only predictions)")
        
        # 5. Load model
        print("🧠 Loading ML model...")
        self.model = self._load_model()
        param_count = sum(p.numel() for p in self.model.parameters())
        print(f"✓ Model loaded: {param_count:,} parameters")
        
        # 6. Create predictor
        print("🔮 Creating character predictor...")
        centroid_dict = self.centroid_service.export_to_dict() if self.centroid_service else None
        self.character_predictor = CharacterPredictor(
            model=self.model,
            classes=self.classes,
            centroid_neighbors=centroid_dict,
            device=self.device
        )
        print("✓ Character predictor ready")
        
        # 7. Create word segmenter
        print("📝 Creating word segmenter...")
        self.word_segmenter = WordSegmenter(
            character_predictor=self.character_predictor
        )
        print("✓ Word segmenter ready")
        
        self.is_initialized = True
        print("✅ AksharaVision initialized successfully!\n")
    
    def _load_classes(self) -> List[str]:
        """Load class labels from JSON"""
        classes_path = Path(settings.classes_path)
        
        if not classes_path.exists():
            print(f"⚠ Classes file not found: {classes_path}")
            print("  Using default class names")
            return [f"class_{i}" for i in range(113)]
        
        try:
            with open(classes_path, "r", encoding="utf-8") as f:
                classes = json.load(f)
            return classes
        except Exception as e:
            print(f"✗ Error loading classes: {e}")
            return [f"class_{i}" for i in range(113)]
    
    def _load_centroid_service(self) -> Optional[CentroidLookupService]:
        """Load centroid lookup service"""
        centroid_path = settings.centroid_path
        
        if not Path(centroid_path).exists():
            print(f"⚠ Centroid file not found: {centroid_path}")
            return None
        
        try:
            service = CentroidLookupService(centroid_path)
            return service if service.lookup_table else None
        except Exception as e:
            print(f"✗ Error loading centroid service: {e}")
            return None
    
    def _load_model(self) -> KannadaClassifier:
        """Load and initialize model"""
        num_classes = len(self.classes)
        
        # Create model
        model = KannadaClassifier(
            backbone_name='swin_tiny_patch4_window7_224',
            embed_dim=512,
            num_classes=num_classes,
            dropout=0.35
        )
        
        # Load checkpoint if exists
        checkpoint_path = Path(settings.model_path)
        if checkpoint_path.exists():
            model = load_checkpoint(
                model,
                str(checkpoint_path),
                device=self.device,
                strict=False
            )
        else:
            print(f"⚠ Checkpoint not found: {checkpoint_path}")
            print("  Using randomly initialized model")
        
        # Move to device and set to eval mode
        model = model.to(self.device)
        model.eval()
        
        return model
    
    def reload_model(self, new_checkpoint_path: str):
        """
        Reload model with new checkpoint (for retraining updates)
        
        Args:
            new_checkpoint_path: Path to new checkpoint file
        """
        print(f"🔄 Reloading model from {new_checkpoint_path}...")
        
        try:
            self.model = load_checkpoint(
                self.model,
                new_checkpoint_path,
                device=self.device,
                strict=False
            )
            self.model.eval()
            
            # Update predictor with new model
            centroid_dict = self.centroid_service.export_to_dict() if self.centroid_service else None
            self.character_predictor = CharacterPredictor(
                model=self.model,
                classes=self.classes,
                centroid_neighbors=centroid_dict,
                device=self.device
            )
            
            # Update word segmenter
            self.word_segmenter = WordSegmenter(
                character_predictor=self.character_predictor
            )
            
            print("✓ Model reloaded successfully")
            
        except Exception as e:
            print(f"✗ Error reloading model: {e}")
            raise


# Global application state singleton
app_state = ApplicationState()


def get_app_state() -> ApplicationState:
    """
    Get application state singleton
    
    Returns:
        ApplicationState instance
    """
    return app_state


def initialize_app():
    """
    Initialize application
    Should be called in FastAPI startup event
    """
    app_state.initialize()


# Convenience functions for accessing components
def get_character_predictor() -> CharacterPredictor:
    """Get character predictor instance"""
    if not app_state.is_initialized:
        raise RuntimeError("Application not initialized. Call initialize_app() first.")
    return app_state.character_predictor


def get_word_segmenter() -> WordSegmenter:
    """Get word segmenter instance"""
    if not app_state.is_initialized:
        raise RuntimeError("Application not initialized. Call initialize_app() first.")
    return app_state.word_segmenter
