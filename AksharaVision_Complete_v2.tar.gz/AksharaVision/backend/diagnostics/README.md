# Diagnostics Directory

Contains analysis and diagnostic files for model performance.

## Files

- **centroid_top3_neighbors.csv**: Precomputed class similarities
  - Each row: class_id, nearest_neighbor1, neighbor2, neighbor3
  - Used for centroid-based prediction refinement
  - Improves edge case accuracy

## Generating Centroid Data

```python
# After training, compute class centroids from embeddings
# Find K-nearest neighbors for each class
# Export to CSV
```
