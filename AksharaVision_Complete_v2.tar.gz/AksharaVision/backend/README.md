# AksharaVision Backend

FastAPI-based backend for Kannada OCR system.

## Features

- **Character OCR**: Swin Transformer-based character recognition
- **Word Segmentation**: Progressive character splitting
- **Feedback System**: Image storage in PostgreSQL (BYTEA)
- **Retraining Pipeline**: Automated model updates
- **RESTful API**: FastAPI with automatic documentation

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Configure
cp .env.example .env
# Edit .env with your settings

# Initialize database
alembic upgrade head

# Run server
uvicorn app.main:app --reload
```

## API Endpoints

- `GET /health` - Health check
- `POST /api/ocr/predict` - Character prediction
- `POST /api/segmentation/segment` - Word segmentation
- `POST /api/feedback/character` - Save character feedback
- `POST /api/feedback/segmentation` - Save segmentation feedback

## Documentation

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Project Structure

```
backend/
├── app/
│   ├── api/           # API routes
│   ├── models/        # ML models
│   ├── inference/     # Prediction pipelines
│   ├── services/      # Business logic
│   ├── db/            # Database layer
│   ├── config.py      # Configuration
│   └── main.py        # Application entry
├── alembic/           # Database migrations
├── project_files/     # Model checkpoints
├── scripts/           # Utility scripts
└── training/          # Retraining pipeline
```

## Development

```bash
# Run tests
pytest

# Format code
black app/

# Type checking
mypy app/
```

## Environment Variables

See `.env.example` for all configuration options.

Key variables:
- `DATABASE_URL`: PostgreSQL connection string
- `MODEL_PATH`: Path to model checkpoint
- `DEVICE`: 'cuda' or 'cpu'
- `FEEDBACK_THRESHOLD`: Trigger retraining after N feedbacks

## Deployment

See `../DEPLOYMENT.md` for production deployment instructions.
