# Model Files Directory

Place your trained model files here:

## Required Files

1. **kannada_classifier_finetuned_full.pth**
   - Your trained PyTorch model checkpoint
   - Format: state_dict with model weights
   - Size: ~100-500MB depending on architecture

2. **classes_list_113_kannada.json**
   - JSON array of 113 Kannada character class labels
   - Format: ["000_ಕ", "001_ಖ", ...]
   - Included: Sample placeholder

3. **centroid_top3_neighbors.csv** (optional)
   - CSV with class centroids and nearest neighbors
   - Format: class_id,neighbor1,neighbor2,neighbor3
   - Improves prediction accuracy via similarity lookup

## Placeholder Mode

If model files are missing, system runs with:
- Randomly initialized weights (for testing only)
- Default class names: class_0, class_1, ...
- No centroid refinement

## Getting Model Files

After training your model:
```python
# Save model
torch.save(model.state_dict(), 'kannada_classifier_finetuned_full.pth')

# Save classes
import json
with open('classes_list_113_kannada.json', 'w') as f:
    json.dump(class_labels, f)
```
