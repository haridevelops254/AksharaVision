"""Initial schema

Revision ID: 001_initial
Revises: 
Create Date: 2026-02-04

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '001_initial'
down_revision = None
branch_labels = None
depends_on = None

def upgrade() -> None:
    # Inference logs
    op.create_table(
        'inference_logs',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('image_name', sa.String(255), nullable=True),
        sa.Column('image_data', sa.LargeBinary(), nullable=True),
        sa.Column('top1_label', sa.String(50), nullable=True),
        sa.Column('top1_char', sa.String(10), nullable=True),
        sa.Column('top1_conf', sa.Float(), nullable=True),
        sa.Column('top2_label', sa.String(50), nullable=True),
        sa.Column('top2_char', sa.String(10), nullable=True),
        sa.Column('top2_conf', sa.Float(), nullable=True),
        sa.Column('top3_label', sa.String(50), nullable=True),
        sa.Column('top3_char', sa.String(10), nullable=True),
        sa.Column('top3_conf', sa.Float(), nullable=True),
        sa.Column('inference_time_ms', sa.Float(), nullable=True),
        sa.Column('model_version', sa.String(50), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_inference_logs_top1', 'inference_logs', ['top1_label'])
    op.create_index('idx_inference_logs_created', 'inference_logs', ['created_at'])

    # Character feedback
    op.create_table(
        'character_feedback',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('image_data', sa.LargeBinary(), nullable=False),
        sa.Column('image_name', sa.String(255), nullable=True),
        sa.Column('image_format', sa.String(10), nullable=True),
        sa.Column('top1_label', sa.String(50), nullable=True),
        sa.Column('top2_label', sa.String(50), nullable=True),
        sa.Column('top3_label', sa.String(50), nullable=True),
        sa.Column('correct_label', sa.String(50), nullable=False),
        sa.Column('feedback_type', sa.String(50), nullable=True),
        sa.Column('user_notes', sa.Text(), nullable=True),
        sa.Column('used_for_training', sa.Boolean(), nullable=True),
        sa.Column('training_batch_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_char_feedback_correct', 'character_feedback', ['correct_label'])
    op.create_index('idx_char_feedback_training', 'character_feedback', ['used_for_training'])
    op.create_index('idx_char_feedback_created', 'character_feedback', ['created_at'])

    # Segmentation feedback
    op.create_table(
        'segmentation_feedback',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('image_data', sa.LargeBinary(), nullable=False),
        sa.Column('image_name', sa.String(255), nullable=True),
        sa.Column('chosen_split', sa.Integer(), nullable=False),
        sa.Column('chosen_word', sa.String(200), nullable=False),
        sa.Column('all_splits_json', postgresql.JSON(astext_type=sa.Text()), nullable=True),
        sa.Column('used_for_training', sa.Boolean(), nullable=True),
        sa.Column('training_batch_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_seg_feedback_training', 'segmentation_feedback', ['used_for_training'])
    op.create_index('idx_seg_feedback_created', 'segmentation_feedback', ['created_at'])

    # Model versions
    op.create_table(
        'model_versions',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('version', sa.String(50), nullable=False),
        sa.Column('model_path', sa.String(500), nullable=False),
        sa.Column('training_feedback_count', sa.Integer(), nullable=True),
        sa.Column('training_accuracy', sa.Float(), nullable=True),
        sa.Column('training_loss', sa.Float(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('deployed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('version')
    )
    op.create_index('idx_model_versions_active', 'model_versions', ['is_active'])

    # Users table
    op.create_table(
        'users',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('username', sa.String(100), nullable=False),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('hashed_password', sa.String(255), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('is_admin', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('last_login', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('username'),
        sa.UniqueConstraint('email')
    )
    op.create_index('idx_users_username', 'users', ['username'])
    op.create_index('idx_users_email', 'users', ['email'])

def downgrade() -> None:
    op.drop_table('users')
    op.drop_table('model_versions')
    op.drop_table('segmentation_feedback')
    op.drop_table('character_feedback')
    op.drop_table('inference_logs')
