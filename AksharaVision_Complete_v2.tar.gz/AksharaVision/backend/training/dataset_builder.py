from torch.utils.data import Dataset
from PIL import Image
import io

class FeedbackDataset(Dataset):
    def __init__(self, feedback_records, transforms=None):
        self.records = feedback_records
        self.transforms = transforms
    
    def __len__(self):
        return len(self.records)
    
    def __getitem__(self, idx):
        record = self.records[idx]
        image_bytes = record.image_data
        label = record.correct_label
        
        image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        
        if self.transforms:
            image = self.transforms(image)
        
        return image, label
