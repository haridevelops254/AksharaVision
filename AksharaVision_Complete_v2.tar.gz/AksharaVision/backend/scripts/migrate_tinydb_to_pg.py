#!/usr/bin/env python3
# Optional: Migration script from TinyDB to PostgreSQL
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

print("Migration from TinyDB to PostgreSQL")
print("This script would convert existing TinyDB data to PostgreSQL format")
print("Run after setting up PostgreSQL database")
