-- Initial database schema for AksharaVision
-- PostgreSQL

-- Inference logs table
CREATE TABLE IF NOT EXISTS inference_logs (
    id SERIAL PRIMARY KEY,
    image_name VARCHAR(255),
    image_data BYTEA,
    top1_label VARCHAR(50),
    top1_char VARCHAR(10),
    top1_conf FLOAT,
    top2_label VARCHAR(50),
    top2_char VARCHAR(10),
    top2_conf FLOAT,
    top3_label VARCHAR(50),
    top3_char VARCHAR(10),
    top3_conf FLOAT,
    inference_time_ms FLOAT,
    model_version VARCHAR(50) DEFAULT 'v1.0',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_inference_logs_top1 ON inference_logs(top1_label);
CREATE INDEX IF NOT EXISTS idx_inference_logs_created ON inference_logs(created_at);

-- Character feedback table
CREATE TABLE IF NOT EXISTS character_feedback (
    id SERIAL PRIMARY KEY,
    image_data BYTEA NOT NULL,
    image_name VARCHAR(255),
    image_format VARCHAR(10) DEFAULT 'png',
    top1_label VARCHAR(50),
    top2_label VARCHAR(50),
    top3_label VARCHAR(50),
    correct_label VARCHAR(50) NOT NULL,
    feedback_type VARCHAR(50),
    user_notes TEXT,
    used_for_training BOOLEAN DEFAULT FALSE,
    training_batch_id INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_char_feedback_correct ON character_feedback(correct_label);
CREATE INDEX IF NOT EXISTS idx_char_feedback_training ON character_feedback(used_for_training);
CREATE INDEX IF NOT EXISTS idx_char_feedback_created ON character_feedback(created_at);

-- Segmentation feedback table
CREATE TABLE IF NOT EXISTS segmentation_feedback (
    id SERIAL PRIMARY KEY,
    image_data BYTEA NOT NULL,
    image_name VARCHAR(255),
    chosen_split INTEGER NOT NULL,
    chosen_word VARCHAR(200) NOT NULL,
    all_splits_json JSONB,
    used_for_training BOOLEAN DEFAULT FALSE,
    training_batch_id INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_seg_feedback_training ON segmentation_feedback(used_for_training);
CREATE INDEX IF NOT EXISTS idx_seg_feedback_created ON segmentation_feedback(created_at);

-- Model versions table
CREATE TABLE IF NOT EXISTS model_versions (
    id SERIAL PRIMARY KEY,
    version VARCHAR(50) UNIQUE NOT NULL,
    model_path VARCHAR(500) NOT NULL,
    training_feedback_count INTEGER,
    training_accuracy FLOAT,
    training_loss FLOAT,
    is_active BOOLEAN DEFAULT FALSE,
    deployed_at TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_model_versions_active ON model_versions(is_active);

-- Users table (optional)
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    hashed_password VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
