#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.services.feedback_service import FeedbackService
from app.config import settings

def check_and_trigger_retraining():
    db = SessionLocal()
    try:
        if FeedbackService.should_trigger_retraining(db, settings.feedback_threshold):
            print(f"✓ Threshold reached ({settings.feedback_threshold} feedback entries)")
            print("🔄 Triggering retraining job...")
            # Add actual retraining logic here
            # For now, just print notification
            return True
        else:
            count = FeedbackService.get_character_feedback_count(db, unused_only=True)
            print(f"Feedback count: {count}/{settings.feedback_threshold}")
            return False
    finally:
        db.close()

if __name__ == "__main__":
    check_and_trigger_retraining()
