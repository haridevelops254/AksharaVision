# 🚀 AksharaVision Quick Start Guide

## ⚡ Get Running in 5 Minutes

### Prerequisites Check
```bash
python --version  # Should be 3.9+
node --version    # Should be 18+
psql --version    # Should be 15+
```

---

## 🏃 Quick Start (Local Development)

### Step 1: Clone and Setup
```bash
git clone <your-repo-url>
cd AksharaVision
```

### Step 2: Backend Setup
```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
```

**Edit `.env` file:**
```bash
DATABASE_URL=postgresql://username:password@localhost:5432/aksharavision
DEVICE=cuda  # or 'cpu' if no GPU
DEBUG=True
```

### Step 3: Database Setup
```bash
# Create database
createdb aksharavision

# Run migrations
alembic upgrade head

# OR use SQL script directly
psql aksharavision < scripts/init_db.sql
```

### Step 4: Add Model Files
Place these files in `backend/project_files/`:
- `kannada_classifier_finetuned_full.pth` (your trained model)
- `classes_list_113_kannada.json` (class labels)
- `../diagnostics/centroid_top3_neighbors.csv` (neighbor lookup)

**Don't have model files?** The system will run with randomly initialized weights (for testing).

### Step 5: Start Backend
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

✅ Backend running at: http://localhost:8000
📚 API Docs at: http://localhost:8000/docs

### Step 6: Frontend Setup (New Terminal)
```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

✅ Frontend running at: http://localhost:5173

### Step 7: Test It!
1. Open http://localhost:5173
2. Upload a Kannada character image
3. Click "Predict"
4. See top-3 predictions
5. Provide feedback!

---

## 🐳 Docker Quick Start (Even Easier!)

### Prerequisites
- Docker
- Docker Compose

### One Command Deployment
```bash
cd AksharaVision
docker-compose -f docker/docker-compose.yml up --build
```

Access:
- Frontend: http://localhost:80
- Backend: http://localhost:8000
- Database: localhost:5432

---

## 📁 Project Structure Explained

```
AksharaVision/
├── backend/                    # FastAPI Backend
│   ├── app/
│   │   ├── api/               # REST endpoints
│   │   ├── models/            # ML model definition
│   │   ├── inference/         # Prediction logic
│   │   ├── services/          # Business logic
│   │   ├── db/                # Database layer
│   │   ├── config.py          # Configuration
│   │   └── main.py            # FastAPI app
│   ├── project_files/         # 🔴 PUT YOUR MODEL HERE
│   ├── alembic/               # Database migrations
│   └── requirements.txt
│
├── frontend/                   # React Frontend
│   ├── src/
│   │   ├── pages/             # Character & Word OCR
│   │   ├── components/        # UI components
│   │   └── api/               # API client
│   └── package.json
│
├── docker/                     # Docker configs
└── README.md
```

---

## 🎯 Key Features Demo

### 1. Character Recognition
```bash
curl -X POST -F "file=@character.png" \\
  http://localhost:8000/api/ocr/predict
```

Response:
```json
{
  "success": true,
  "predictions": [
    {"label": "001_ಅ", "char": "ಅ", "confidence": 0.95},
    {"label": "002_ಆ", "char": "ಆ", "confidence": 0.03},
    {"label": "003_ಇ", "char": "ಇ", "confidence": 0.02}
  ]
}
```

### 2. Word Segmentation
```bash
curl -X POST -F "file=@word.png" \\
  http://localhost:8000/api/segmentation/segment
```

### 3. Feedback Submission
```bash
curl -X POST -F "file=@character.png" \\
  -F "correct_label=001_ಅ" \\
  -F "top1_label=002_ಆ" \\
  http://localhost:8000/api/feedback/character
```

---

## 🔧 Troubleshooting

### Issue: "Module not found"
```bash
# Make sure you're in virtual environment
source venv/bin/activate
pip install -r requirements.txt
```

### Issue: "Database connection failed"
```bash
# Check PostgreSQL is running
pg_isready

# Check credentials in .env match your database
# Default PostgreSQL user is usually 'postgres'
```

### Issue: "Model file not found"
```bash
# Model is optional for testing
# System will use randomly initialized weights
# To add model, place .pth file in backend/project_files/
```

### Issue: "Port already in use"
```bash
# Backend (8000)
lsof -ti:8000 | xargs kill -9

# Frontend (5173)
lsof -ti:5173 | xargs kill -9
```

---

## 📊 Check System Health

### Backend Health
```bash
curl http://localhost:8000/health
```

Expected:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "database": "connected"
}
```

### Database Check
```bash
psql aksharavision -c "SELECT COUNT(*) FROM inference_logs;"
```

---

## 🎓 Next Steps

1. **Add Your Model**: Replace placeholder with your trained `.pth` file
2. **Test Predictions**: Upload various Kannada characters
3. **Collect Feedback**: Use feedback feature to gather corrections
4. **Monitor Logs**: Check `backend/logs/` for inference results
5. **Deploy**: See DEPLOYMENT.md for production deployment

---

## 📚 Documentation

- **API Docs**: http://localhost:8000/docs (Swagger UI)
- **Deployment**: See `DEPLOYMENT.md`
- **Contributing**: See `CONTRIBUTING.md`
- **Full README**: See main `README.md`

---

## 🆘 Need Help?

1. Check logs: `backend/logs/app.log`
2. Verify environment variables: `cat backend/.env`
3. Test database: `psql aksharavision`
4. Open issue on GitHub

---

## ✨ Features Overview

- ✅ Character-level OCR with top-3 predictions
- ✅ Centroid-based refinement for better accuracy
- ✅ Progressive word segmentation (2-5 character splits)
- ✅ Feedback system with image storage (BYTEA)
- ✅ Automated retraining trigger (10,000 feedback threshold)
- ✅ Production-ready FastAPI backend
- ✅ Modern React frontend
- ✅ PostgreSQL with Alembic migrations
- ✅ Docker deployment support
- ✅ Render/Railway ready

---

**Built with ❤️ for Kannada language preservation**
