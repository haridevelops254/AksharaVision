# 🚀 Complete Deployment Guide - Render & Railway

## Quick Links
- [Render Deployment (Easiest)](#render-deployment)
- [Railway Deployment (Fastest)](#railway-deployment)
- [Troubleshooting](#troubleshooting)

---

## Render Deployment

### Prerequisites
- GitHub account
- Render account (free at https://render.com)

### Total Time: ~20 minutes

---

### Step 1: Push to GitHub (5 minutes)

```bash
# Extract and navigate
tar -xzf AksharaVision_Complete.tar.gz
cd AksharaVision

# Initialize Git
git init
git add .
git commit -m "Initial commit: AksharaVision v1.0"

# Create repo on GitHub (https://github.com/new)
# Then connect:
git remote add origin https://github.com/YOUR_USERNAME/AksharaVision.git
git branch -M main
git push -u origin main
```

---

### Step 2: Create PostgreSQL Database (2 minutes)

1. Go to https://dashboard.render.com
2. Click **"New +"** → **"PostgreSQL"**
3. Settings:
   ```
   Name: aksharavision-db
   Database: aksharavision
   User: aksharavision_user
   Region: Oregon (or closest to you)
   Plan: Free
   ```
4. Click **"Create Database"**
5. ⚠️ **IMPORTANT**: Copy **"Internal Database URL"** 
   - Format: `postgresql://user:pass@host/dbname`
   - You'll need this for backend!

---

### Step 3: Deploy Backend (8 minutes)

1. Click **"New +"** → **"Web Service"**
2. Click **"Connect Repository"** → Select your GitHub repo
3. Settings:
   ```
   Name: aksharavision-backend
   Region: Oregon (same as database!)
   Branch: main
   Root Directory: backend
   Runtime: Python 3
   
   Build Command:
   pip install -r requirements.txt && alembic upgrade head
   
   Start Command:
   uvicorn app.main:app --host 0.0.0.0 --port $PORT
   
   Plan: Free
   ```

4. **Environment Variables** (Click "Advanced"):
   ```
   DATABASE_URL = <paste Internal URL from Step 2>
   DEVICE = cpu
   DEBUG = False
   SECRET_KEY = <generate random: openssl rand -hex 32>
   CORS_ORIGINS = https://YOUR-FRONTEND-NAME.onrender.com
   FEEDBACK_THRESHOLD = 10000
   MODEL_PATH = project_files/kannada_classifier_finetuned_full.pth
   CLASSES_PATH = project_files/classes_list_113_kannada.json
   ```
   
   ⚠️ **For CORS_ORIGINS**: You'll update this after deploying frontend!

5. Click **"Create Web Service"**

6. Wait for deployment (shows "Live" when ready)

7. **Copy your backend URL**:
   - Format: `https://aksharavision-backend.onrender.com`
   - Click the URL at top of page

---

### Step 4: Deploy Frontend (3 minutes)

1. Click **"New +"** → **"Static Site"**
2. Connect your repository again
3. Settings:
   ```
   Name: aksharavision-frontend
   Branch: main
   Root Directory: frontend
   
   Build Command:
   npm install && npm run build
   
   Publish Directory: dist
   ```

4. **Environment Variables**:
   ```
   VITE_API_BASE = https://YOUR-BACKEND-URL.onrender.com/api
   ```
   (Replace with actual backend URL from Step 3)

5. Click **"Create Static Site"**

6. Wait for deployment

7. **Copy your frontend URL**

---

### Step 5: Fix CORS (2 minutes)

Now that you have both URLs, update backend CORS:

1. Go to your **backend service** on Render
2. Click **"Environment"** in left sidebar
3. Find `CORS_ORIGINS` variable
4. Update to your **actual frontend URL**:
   ```
   CORS_ORIGINS = https://aksharavision-frontend.onrender.com
   ```
5. Click **"Save Changes"**
6. Backend will auto-redeploy (2-3 minutes)

---

### Step 6: Add Model Files (CRITICAL!)

**Option A: Git LFS (if model < 100MB)**
```bash
cd backend/project_files

# Install Git LFS
git lfs install
git lfs track "*.pth"

# Add your model
cp /path/to/your/kannada_classifier_finetuned_full.pth .
git add .
git commit -m "Add model weights"
git push
```

**Option B: Render Disk (Recommended for large models)**
1. In backend service, go to **"Disks"** tab
2. Click **"Add Disk"**:
   ```
   Name: model-files
   Mount Path: /opt/render/project/src/project_files
   Size: 1 GB
   ```
3. Upload via SFTP:
   ```bash
   # Get SFTP credentials from Render dashboard
   sftp user@your-instance.onrender.com
   > cd /opt/render/project/src/project_files
   > put kannada_classifier_finetuned_full.pth
   > put classes_list_113_kannada.json
   ```

**Option C: Cloud Storage (Best for production)**
Use S3/GCS and update `MODEL_PATH` environment variable to download from cloud.

---

### Step 7: Test Everything! ✅

1. **Health Check**:
   ```bash
   curl https://your-backend.onrender.com/health
   ```
   Should return: `{"status": "healthy"}`

2. **Frontend Access**:
   - Visit: `https://your-frontend.onrender.com`
   - Should see AksharaVision UI

3. **Test Prediction**:
   - Upload a character image
   - Click "Predict"
   - Should see top-3 predictions

4. **Test Feedback**:
   - Submit a correction
   - Check database (via Render dashboard)

---

## Railway Deployment

### Prerequisites
- Railway account (https://railway.app)
- Railway CLI installed

### Total Time: ~10 minutes

---

### Step 1: Install Railway CLI

```bash
# Install CLI
npm install -g @railway/cli

# Login
railway login
# Opens browser for authentication
```

---

### Step 2: Initialize Project

```bash
# Extract project
tar -xzf AksharaVision_Complete.tar.gz
cd AksharaVision

# Initialize Railway
railway init
# Enter project name: AksharaVision
```

---

### Step 3: Add PostgreSQL

```bash
railway add
# Select: PostgreSQL

# DATABASE_URL is automatically set!
```

---

### Step 4: Deploy Backend

```bash
cd backend

# Deploy
railway up

# Railway auto-detects:
# - Python project
# - requirements.txt
# - Runs migrations
```

---

### Step 5: Configure Backend

```bash
# Set environment variables
railway variables set DEVICE=cpu
railway variables set DEBUG=False
railway variables set SECRET_KEY=$(openssl rand -hex 32)
railway variables set FEEDBACK_THRESHOLD=10000

# Generate domain
railway domain
# Copy the generated URL (e.g., backend.up.railway.app)
```

---

### Step 6: Deploy Frontend

```bash
cd ../frontend

# Deploy
railway up

# Generate domain
railway domain
# Copy frontend URL
```

---

### Step 7: Configure Frontend

```bash
# Set API URL (use backend URL from Step 5)
railway variables set VITE_API_BASE=https://backend.up.railway.app/api

# Redeploy
railway up --detach
```

---

### Step 8: Update Backend CORS

```bash
cd ../backend

# Set CORS (use frontend URL from Step 6)
railway variables set CORS_ORIGINS=https://frontend.up.railway.app

# Redeploy
railway up --detach
```

---

### Step 9: Run Migrations

```bash
# Run migrations in Railway environment
railway run alembic upgrade head
```

---

### Step 10: Add Model Files

**Option A: Include in git**
```bash
cd project_files
git add kannada_classifier_finetuned_full.pth
git commit -m "Add model"
git push
railway up
```

**Option B: Railway Volumes**
1. Go to Railway dashboard
2. Select your backend service
3. Click "Volumes" tab
4. Add volume: `/app/project_files`
5. Upload files via Railway CLI or dashboard

---

## Troubleshooting

### Issue: "Database connection failed"

**Render:**
```bash
# Verify DATABASE_URL is set
# In dashboard: Environment → DATABASE_URL

# Test connection
railway run python -c "from app.db.session import check_db_connection; check_db_connection()"
```

**Railway:**
```bash
railway variables
# Check DATABASE_URL exists
```

---

### Issue: "CORS error"

**Solution:**
1. Check backend `CORS_ORIGINS` includes frontend URL
2. Must be EXACT match (no trailing slash!)
3. Update and redeploy backend

**Test:**
```bash
curl -H "Origin: https://your-frontend.com" \
  -I https://your-backend.com/health
# Should see: Access-Control-Allow-Origin header
```

---

### Issue: "Model not loading"

**Check:**
```bash
# Render: Check build logs
# Look for: "Model loaded successfully"

# Railway:
railway logs
# Look for startup messages
```

**Solution:**
1. Verify model file exists in `project_files/`
2. Check file permissions
3. Verify `MODEL_PATH` environment variable
4. Model file should be in git or attached disk/volume

---

### Issue: "Build failing"

**Render:**
- Check build logs in dashboard
- Common: Missing dependencies in requirements.txt
- Solution: `pip freeze > requirements.txt`

**Railway:**
```bash
railway logs --build
# Shows build errors
```

---

### Issue: "Frontend shows blank page"

**Check:**
1. Browser console for errors
2. Verify `VITE_API_BASE` is set correctly
3. Check network tab - are API calls failing?

**Solution:**
```bash
# Rebuild frontend with correct API URL
# Render: Update env var and redeploy
# Railway: 
railway variables set VITE_API_BASE=https://correct-url.com/api
railway up
```

---

### Issue: "Migrations not running"

**Render:**
- Migrations run in build command
- Check build logs for errors

**Railway:**
```bash
# Run manually:
railway run alembic upgrade head

# Check current version:
railway run alembic current
```

---

## Production Checklist

Before going live:

- [ ] Database backups enabled
- [ ] `DEBUG=False` set
- [ ] Strong `SECRET_KEY` generated
- [ ] CORS restricted to your domain
- [ ] Model files uploaded
- [ ] Health endpoint responding
- [ ] Test character prediction
- [ ] Test word segmentation
- [ ] Test feedback submission
- [ ] SSL/HTTPS working (automatic on both platforms)
- [ ] Environment variables documented
- [ ] Monitoring/alerts set up

---

## Monitoring

### Render
- Dashboard → Service → Logs
- Dashboard → Service → Metrics
- Set up uptime monitoring (external)

### Railway
```bash
# View logs
railway logs

# Monitor in dashboard
railway open
```

### Health Checks
```bash
# Add to UptimeRobot or similar
https://your-backend.com/health

# Should return:
{"status": "healthy", "database": "connected"}
```

---

## Scaling

### Render
1. Upgrade from Free → Starter plan
2. Add more instances (horizontal scaling)
3. Increase instance size (vertical scaling)

### Railway
1. Automatic scaling based on usage
2. Add more services (horizontal)
3. Upgrade plan for more resources

---

## Costs

### Render Free Tier
- ✅ PostgreSQL: 1GB storage
- ✅ Web Service: 750 hours/month
- ✅ Static Site: Unlimited
- ⚠️ Services sleep after 15min inactivity

### Railway Free Tier
- ✅ $5 credit/month
- ✅ No sleep (stays active)
- ⚠️ Credit-based (monitor usage)

### Recommendations
- **Development**: Use free tier
- **Production**: Upgrade to paid (~$7-20/month)

---

## Support

**Render:** https://render.com/docs
**Railway:** https://docs.railway.app

**AksharaVision Issues:**
- Check logs first
- Review environment variables
- Test locally to isolate cloud vs code issues
- Open GitHub issue with error details

---

## Success! 🎉

Your AksharaVision system is now:
- ✅ Deployed to production
- ✅ Accessible via HTTPS
- ✅ Backed by PostgreSQL
- ✅ Ready for users
- ✅ Ready to collect feedback
- ✅ Ready for retraining

**Next Steps:**
1. Share your frontend URL
2. Collect feedback
3. Monitor performance
4. Set up retraining cron job
5. Enjoy your production OCR system!
