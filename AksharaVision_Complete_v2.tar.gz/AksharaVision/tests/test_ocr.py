import pytest
from app.main import app
from fastapi.testclient import TestClient

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] in ["healthy", "degraded"]

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "name" in response.json()
