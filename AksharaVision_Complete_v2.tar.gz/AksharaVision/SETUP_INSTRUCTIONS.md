# 🪶 AksharaVision - Complete Setup Instructions

## 📦 What You Have

This is a **production-ready, full-stack Kannada OCR system** converted from your Gradio prototype. It includes:

✅ **69 files** across backend, frontend, database, and deployment configs
✅ **FastAPI backend** with REST API, database layer, and ML inference
✅ **React frontend** with modern UI and real-time predictions
✅ **PostgreSQL database** with Alembic migrations
✅ **Docker deployment** configs for easy deployment
✅ **Automated retraining** pipeline for continuous improvement
✅ **Comprehensive documentation** for setup and deployment

---

## 🚀 Getting Started (Choose Your Path)

### Path A: Quick Local Development (10 minutes)

1. **Extract the Project**
   ```bash
   tar -xzf AksharaVision_Complete.tar.gz
   cd AksharaVision
   ```

2. **Install PostgreSQL** (if not already installed)
   ```bash
   # Ubuntu/Debian
   sudo apt install postgresql postgresql-contrib

   # macOS
   brew install postgresql@15

   # Windows
   # Download from https://www.postgresql.org/download/windows/
   ```

3. **Create Database**
   ```bash
   createdb aksharavision
   ```

4. **Setup Backend**
   ```bash
   cd backend
   python3 -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   
   # Configure environment
   cp .env.example .env
   # Edit .env and set: DATABASE_URL=postgresql://YOUR_USER:YOUR_PASS@localhost:5432/aksharavision
   
   # Run migrations
   alembic upgrade head
   
   # Start server
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

5. **Setup Frontend** (new terminal)
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

6. **Access Application**
   - Frontend: http://localhost:5173
   - Backend API Docs: http://localhost:8000/docs
   - Health Check: http://localhost:8000/health

### Path B: Docker Deployment (5 minutes)

1. **Extract and Navigate**
   ```bash
   tar -xzf AksharaVision_Complete.tar.gz
   cd AksharaVision
   ```

2. **Configure Docker**
   ```bash
   # Edit docker/docker-compose.yml if needed
   # Change PostgreSQL password (recommended)
   ```

3. **Launch Everything**
   ```bash
   docker-compose -f docker/docker-compose.yml up --build
   ```

4. **Access Application**
   - Frontend: http://localhost:80
   - Backend: http://localhost:8000
   - PostgreSQL: localhost:5432

### Path C: Production Deployment (15-30 minutes)

See the detailed guides:
- **QUICKSTART.md** - 5-minute local setup
- **DEPLOYMENT.md** - Full production deployment guide
- **DEPLOYMENT_CHECKLIST.md** - Step-by-step checklist

Recommended platforms:
- **Render.com** (easiest, free tier)
- **Railway.app** (best DX, generous free tier)
- **Docker** (self-hosted on any cloud)

---

## 📁 Project Structure Overview

```
AksharaVision/
├── README.md              # Main documentation
├── QUICKSTART.md          # Fast setup guide
├── PROJECT_SUMMARY.md     # Complete feature overview
├── DEPLOYMENT.md          # Production deployment
├── DEPLOYMENT_CHECKLIST.md # Deployment steps
│
├── backend/               # FastAPI Backend
│   ├── app/              # Application code
│   │   ├── api/         # REST endpoints
│   │   ├── models/      # ML model (Swin Transformer)
│   │   ├── inference/   # Prediction pipelines
│   │   ├── services/    # Business logic
│   │   ├── db/          # Database layer
│   │   └── main.py      # Entry point
│   ├── project_files/   # 🔴 PUT YOUR MODEL HERE
│   ├── alembic/         # Database migrations
│   ├── training/        # Retraining pipeline
│   └── requirements.txt
│
├── frontend/            # React Frontend
│   ├── src/
│   │   ├── pages/      # Character & Word OCR
│   │   ├── components/ # UI components
│   │   └── api/        # API client
│   └── package.json
│
├── docker/              # Docker deployment
│   ├── backend.Dockerfile
│   ├── frontend.Dockerfile
│   └── docker-compose.yml
│
└── tests/               # Test suite
```

---

## 🔑 Critical Files to Know

### 1. **Model Files** (Required for Production)
Location: `backend/project_files/`

You need to add:
- `kannada_classifier_finetuned_full.pth` - Your trained model
- `classes_list_113_kannada.json` - Class labels (placeholder included)
- `diagnostics/centroid_top3_neighbors.csv` - Optional, improves accuracy

**Don't have the model?** System will run with randomly initialized weights for testing.

### 2. **Environment Configuration**
File: `backend/.env`

Copy from `backend/.env.example` and edit:
```bash
DATABASE_URL=postgresql://user:password@host:5432/aksharavision
DEVICE=cuda  # or 'cpu' if no GPU
DEBUG=False  # Set to False in production
MODEL_PATH=project_files/kannada_classifier_finetuned_full.pth
```

### 3. **Database Schema**
Files:
- `backend/scripts/init_db.sql` - Manual SQL script
- `backend/alembic/versions/001_initial.py` - Alembic migration

Initialize with: `alembic upgrade head`

---

## 🎯 Key Features You Get

### 1. **Character Recognition** (was: Gradio Tab 1)
- Upload character image → Get top-3 predictions
- Centroid-based refinement for better accuracy
- Confidence scores for each prediction
- API: `POST /api/ocr/predict`

### 2. **Word Segmentation** (was: Gradio Tab 2)
- Upload word image → Get 2-5 character splits
- Each split shows predicted characters
- Manual override option
- API: `POST /api/segmentation/segment`

### 3. **Feedback System** (replaces TinyDB)
- Store user corrections
- **Images saved as BYTEA in PostgreSQL** (not file paths!)
- Tracks which data is used for retraining
- API: `POST /api/feedback/character` and `/api/feedback/segmentation`

### 4. **Automated Retraining**
- Triggers after 10,000 feedback entries
- Builds PyTorch dataset from PostgreSQL
- Fine-tunes model on corrected data
- Hot-reloads model without downtime
- Job: `backend/jobs/retrain_trigger.py`

### 5. **Production Features**
- ✅ RESTful API with FastAPI
- ✅ Automatic API documentation (Swagger UI)
- ✅ PostgreSQL with migrations (Alembic)
- ✅ React frontend with Vite
- ✅ Docker deployment support
- ✅ CORS configured
- ✅ Health check endpoints
- ✅ Comprehensive logging
- ✅ Ready for Render/Railway

---

## 📊 Database Tables

### `inference_logs`
- All predictions logged automatically
- Includes: image data (BYTEA), top-3 predictions, confidence, inference time
- For analytics and monitoring

### `character_feedback` ⭐ CRITICAL
- User corrections for characters
- Images stored as BYTEA (not paths!)
- Tracks which data is used for retraining
- This table powers the retraining pipeline

### `segmentation_feedback`
- User corrections for word splits
- Stores chosen split and word
- All split attempts saved as JSON

### `model_versions`
- Tracks model evolution
- Records training accuracy, feedback count
- Manages which model is active

---

## 🔄 How Retraining Works

Your original Gradio app saved to TinyDB files. Now:

1. **User corrects prediction** in UI
2. **Backend saves to PostgreSQL**:
   - Image as BYTEA (binary data)
   - Correct label
   - Original predictions
   - Timestamp
3. **Daily job checks feedback count**:
   - If >= 10,000: trigger retraining
4. **Retraining pipeline**:
   - Export unused feedback as PyTorch Dataset
   - Fine-tune model
   - Save new checkpoint
   - Hot-reload in production
   - Mark feedback as used
5. **Continuous improvement!**

---

## 🧪 Testing Your Setup

### 1. **Backend Health Check**
```bash
curl http://localhost:8000/health
```
Expected: `{"status": "healthy", "database": "connected"}`

### 2. **Character Prediction Test**
```bash
curl -X POST -F "file=@test_character.png" \\
  http://localhost:8000/api/ocr/predict
```

### 3. **Frontend Test**
1. Open http://localhost:5173
2. Upload a character image
3. Click "Predict"
4. See top-3 predictions
5. Submit feedback

### 4. **Database Test**
```bash
psql aksharavision -c "SELECT COUNT(*) FROM inference_logs;"
```

---

## 🚨 Common Issues & Solutions

### Issue: "ModuleNotFoundError"
**Solution:** Activate virtual environment
```bash
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
```

### Issue: "Database connection failed"
**Solution:** Check PostgreSQL is running and credentials in `.env` are correct
```bash
pg_isready  # Check if PostgreSQL is running
# Update DATABASE_URL in backend/.env
```

### Issue: "Model file not found"
**Solution:** System runs with random weights for testing. To use trained model:
```bash
# Place your .pth file in:
backend/project_files/kannada_classifier_finetuned_full.pth
```

### Issue: "Port already in use"
**Solution:** Change ports or kill existing process
```bash
# Backend (8000)
lsof -ti:8000 | xargs kill -9

# Frontend (5173)
lsof -ti:5173 | xargs kill -9
```

### Issue: "CORS error in frontend"
**Solution:** Add frontend URL to CORS_ORIGINS in `backend/.env`
```bash
CORS_ORIGINS=http://localhost:5173,http://localhost:3000
```

---

## 📚 Documentation Files

| File | Purpose |
|------|---------|
| `README.md` | Main project overview and features |
| `QUICKSTART.md` | 5-minute setup guide |
| `PROJECT_SUMMARY.md` | Complete technical overview |
| `DEPLOYMENT.md` | Production deployment guide |
| `DEPLOYMENT_CHECKLIST.md` | Step-by-step deployment |
| `CONTRIBUTING.md` | How to contribute |
| `backend/README.md` | Backend-specific docs |

---

## 🎓 Next Steps

1. **Get it running locally** (Path A or B above)
2. **Test with sample images**
3. **Add your trained model** to `backend/project_files/`
4. **Collect feedback** using the UI
5. **Deploy to production** (see DEPLOYMENT.md)
6. **Set up retraining** cron job
7. **Monitor and improve!**

---

## 🆘 Need Help?

1. **Read the docs**: Start with QUICKSTART.md
2. **Check logs**: backend/logs/app.log
3. **Verify config**: backend/.env
4. **Test database**: `psql aksharavision`
5. **API docs**: http://localhost:8000/docs

---

## ✨ What's Different from Gradio?

| Gradio Version | Production Version |
|----------------|-------------------|
| Single Python file | Modular FastAPI app |
| TinyDB (JSON files) | PostgreSQL database |
| Local file storage | BYTEA (binary in DB) |
| No migrations | Alembic migrations |
| No API docs | Automatic OpenAPI docs |
| Single process | Scalable architecture |
| No tests | Test suite included |
| Development only | Production-ready |
| No deployment | Docker + Render/Railway ready |

---

## 🎉 Congratulations!

You now have a **production-grade** Kannada OCR system with:
- ✅ Modern web stack (FastAPI + React)
- ✅ Robust database (PostgreSQL)
- ✅ Automated retraining pipeline
- ✅ Image storage in database (BYTEA)
- ✅ Deployment-ready configuration
- ✅ Comprehensive documentation

**Ready to deploy? See DEPLOYMENT.md**
**Ready to develop? See QUICKSTART.md**

---

**Built with ❤️ for Kannada language preservation**
**Version: 1.0.0 | Production Ready ✅**
