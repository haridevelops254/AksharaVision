# 🪶 AksharaVision — Production Kannada OCR System

**AksharaVision** is a production-grade Kannada handwritten character and word recognition system with human-in-the-loop feedback for continuous model improvement.

## 🎯 Features

- **Character OCR**: Single character recognition with top-3 predictions
- **Word Segmentation**: Progressive word splitting with centroid-based refinement
- **Feedback System**: Store user corrections for model retraining
- **Image Storage**: Direct BYTEA storage in PostgreSQL (not just paths)
- **Retraining Pipeline**: Automated retraining triggers after 10,000 feedback entries
- **Production Ready**: FastAPI + React + PostgreSQL + Alembic migrations

## 🏗️ Architecture

```
Frontend (React) → FastAPI Backend → PostgreSQL
                    ↓
                ML Model (Swin Transformer)
                    ↓
                Feedback Loop → Retraining Pipeline
```

## 📦 Tech Stack

- **Backend**: FastAPI, PyTorch, Timm, SQLAlchemy, Alembic
- **Frontend**: React 18, Vite, TailwindCSS
- **Database**: PostgreSQL 15+
- **ML**: Swin Transformer (fine-tuned on Kannada dataset)
- **Deployment**: Docker, Render/Railway compatible

## 🚀 Quick Start

### Prerequisites

- Python 3.9+
- Node.js 18+
- PostgreSQL 15+
- CUDA-capable GPU (optional, for faster inference)

### 1. Clone and Setup Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your database credentials

# Initialize database
alembic upgrade head

# Run backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 2. Setup Frontend

```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:5173`

### 3. Docker Deployment (Production)

```bash
docker-compose up --build
```

## 📁 Project Structure

```
AksharaVision/
├── backend/               # FastAPI application
│   ├── app/
│   │   ├── api/          # REST endpoints
│   │   ├── models/       # ML model definitions
│   │   ├── inference/    # Prediction logic
│   │   ├── services/     # Business logic
│   │   └── db/           # Database layer
│   ├── project_files/    # Model weights
│   ├── alembic/          # DB migrations
│   └── training/         # Retraining pipeline
├── frontend/             # React application
├── docker/               # Docker configs
└── tests/                # Test suite
```

## 🎓 Model Details

- **Architecture**: Swin Tiny Transformer + Custom Head
- **Classes**: 113 Kannada characters
- **Input Size**: 224x224 RGB
- **Embedding Dim**: 512
- **Training**: Fine-tuned on Kannada handwriting dataset

## 🔄 Feedback & Retraining

1. Users provide corrections via UI
2. System stores:
   - Original image (BYTEA)
   - Top-3 predictions
   - User correction
   - Timestamp
3. After 10,000 feedback entries:
   - Automated retraining job triggers
   - New model version created
   - Old model archived
   - System hot-reloads new weights

## 🌐 API Documentation

Once backend is running, visit:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 📊 Database Schema

**inference_logs**: Stores all predictions
**character_feedback**: User corrections for characters
**segmentation_feedback**: User corrections for word splits
**model_versions**: Tracks model evolution

## 🚢 Deployment

### Render

```bash
# Build command
pip install -r requirements.txt && alembic upgrade head

# Start command
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

### Railway

Railway auto-detects the setup. Just connect your GitHub repo.

## 🧪 Testing

```bash
# Backend tests
cd backend
pytest

# Frontend tests
cd frontend
npm test
```

## 📝 License

MIT License - see LICENSE file

## 🤝 Contributing

Contributions welcome! Please read CONTRIBUTING.md first.

## 📧 Contact

For questions or support, open an issue on GitHub.

---

**Built with ❤️ for Kannada language preservation**
