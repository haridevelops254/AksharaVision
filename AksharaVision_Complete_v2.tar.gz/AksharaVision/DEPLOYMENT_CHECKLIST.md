# 🚀 AksharaVision Deployment Checklist

## Pre-Deployment Checklist

### 📁 Files & Configuration

- [ ] All model files in `backend/project_files/`:
  - [ ] `kannada_classifier_finetuned_full.pth`
  - [ ] `classes_list_113_kannada.json`
  - [ ] `diagnostics/centroid_top3_neighbors.csv` (optional)

- [ ] Environment variables configured:
  - [ ] `DATABASE_URL` set correctly
  - [ ] `SECRET_KEY` changed from default
  - [ ] `DEBUG=False` in production
  - [ ] `CORS_ORIGINS` set to your domains
  - [ ] `DEVICE` set appropriately (cpu/cuda)

- [ ] Dependencies up to date:
  - [ ] `backend/requirements.txt` installed
  - [ ] `frontend/package.json` dependencies installed

### 🗄️ Database

- [ ] PostgreSQL 15+ installed/provisioned
- [ ] Database created
- [ ] Migrations run: `alembic upgrade head`
- [ ] Database connection tested
- [ ] Backup strategy in place

### 🔒 Security

- [ ] Changed default passwords
- [ ] `SECRET_KEY` is strong and unique
- [ ] HTTPS enabled (automatic on Render/Railway)
- [ ] CORS properly configured
- [ ] SQL injection protection (via SQLAlchemy ORM)
- [ ] File upload size limits set

### 🧪 Testing

- [ ] Backend health check works: `curl /health`
- [ ] Character prediction works
- [ ] Word segmentation works
- [ ] Feedback submission works
- [ ] Database writes successful
- [ ] Frontend can reach backend

### 📊 Monitoring

- [ ] Logging configured
- [ ] Health check endpoint accessible
- [ ] Database monitoring enabled
- [ ] Error tracking setup (optional)
- [ ] Uptime monitoring configured

---

## Deployment Options

### ✅ Option 1: Render.com

**Pros:** Free tier, easy setup, automatic HTTPS
**Time:** ~15 minutes

#### Steps:
1. [ ] Create Render account
2. [ ] Create PostgreSQL database
3. [ ] Deploy backend web service
4. [ ] Deploy frontend static site
5. [ ] Upload model files to persistent disk
6. [ ] Set environment variables
7. [ ] Test endpoints

**Backend Environment:**
```
DATABASE_URL=<from-render-postgres>
DEVICE=cpu
DEBUG=False
CORS_ORIGINS=https://your-frontend.onrender.com
```

**Frontend Environment:**
```
VITE_API_BASE=https://your-backend.onrender.com/api
```

### ✅ Option 2: Railway.app

**Pros:** Excellent DX, auto-detects config, generous free tier
**Time:** ~10 minutes

#### Steps:
1. [ ] Install Railway CLI: `npm install -g @railway/cli`
2. [ ] Login: `railway login`
3. [ ] Initialize project: `railway init`
4. [ ] Add PostgreSQL: `railway add`
5. [ ] Deploy backend: `cd backend && railway up`
6. [ ] Deploy frontend: `cd frontend && railway up`
7. [ ] Configure environment variables via CLI or dashboard

### ✅ Option 3: Docker (Self-Hosted)

**Pros:** Full control, any cloud provider
**Time:** ~20 minutes

#### Steps:
1. [ ] Install Docker & Docker Compose
2. [ ] Clone repository to server
3. [ ] Edit `docker/docker-compose.yml`:
   - [ ] Change PostgreSQL password
   - [ ] Add volume for model files
4. [ ] Run: `docker-compose up --build`
5. [ ] Configure reverse proxy (nginx/Caddy)
6. [ ] Setup SSL certificate (Let's Encrypt)

---

## Post-Deployment Checklist

### 🎯 Functionality Tests

- [ ] Frontend loads correctly
- [ ] Can upload character image
- [ ] Character prediction returns results
- [ ] Top-3 predictions displayed
- [ ] Can upload word image
- [ ] Word segmentation returns results
- [ ] Feedback submission works
- [ ] Feedback stored in database

### 📈 Performance Tests

- [ ] Backend response time < 1s for character OCR
- [ ] Backend response time < 3s for word segmentation
- [ ] Frontend loads in < 2s
- [ ] No memory leaks after 100 requests
- [ ] Database queries are indexed and fast

### 🔍 Verification

```bash
# Test health endpoint
curl https://your-backend-url.com/health

# Test character prediction
curl -X POST -F "file=@test_char.png" \\
  https://your-backend-url.com/api/ocr/predict

# Test segmentation
curl -X POST -F "file=@test_word.png" \\
  https://your-backend-url.com/api/segmentation/segment

# Check database
psql $DATABASE_URL -c "SELECT COUNT(*) FROM inference_logs;"
```

### 📊 Monitoring Setup

- [ ] Health check URL added to uptime monitor
- [ ] Log aggregation configured
- [ ] Database backup schedule set
- [ ] Disk usage alerts configured
- [ ] Error notifications setup

---

## Maintenance Checklist

### Daily
- [ ] Check application health
- [ ] Review error logs
- [ ] Monitor database size

### Weekly
- [ ] Review feedback statistics
- [ ] Check disk usage
- [ ] Verify backups

### Monthly
- [ ] Update dependencies
- [ ] Review and optimize database
- [ ] Assess need for retraining
- [ ] Review access logs

### Quarterly
- [ ] Security audit
- [ ] Performance optimization
- [ ] Database cleanup (old logs)
- [ ] Model retraining if threshold reached

---

## Retraining Pipeline

### Manual Trigger
```bash
# Check feedback count
curl https://your-backend-url.com/api/feedback/stats

# If count >= 10,000, trigger retraining
python backend/jobs/retrain_trigger.py
```

### Automated (Recommended)
Set up cron job or scheduled task:
```cron
# Run every day at 2 AM
0 2 * * * cd /path/to/AksharaVision/backend && python jobs/retrain_trigger.py
```

### Retraining Steps
1. [ ] Export unused feedback as dataset
2. [ ] Run training script
3. [ ] Evaluate new model
4. [ ] Save model as new version
5. [ ] Hot-reload model in production
6. [ ] Mark feedback as used
7. [ ] Monitor new model performance

---

## Rollback Plan

If deployment fails:

1. **Backend Issues:**
   - [ ] Roll back to previous version
   - [ ] Check logs: `railway logs` or Render dashboard
   - [ ] Verify environment variables
   - [ ] Check database connectivity

2. **Database Issues:**
   - [ ] Restore from backup
   - [ ] Roll back migrations: `alembic downgrade -1`
   - [ ] Check connection string

3. **Model Issues:**
   - [ ] Revert to previous model version
   - [ ] Check model file permissions
   - [ ] Verify model path in environment

---

## Success Criteria

✅ **Deployment is successful when:**
- [ ] Frontend loads without errors
- [ ] Character OCR works with <1s latency
- [ ] Word segmentation completes in <3s
- [ ] Feedback saves to database
- [ ] No critical errors in logs
- [ ] Health check returns "healthy"
- [ ] Database backups are running
- [ ] Monitoring alerts are configured

---

## Support & Documentation

- **Quick Start:** See `QUICKSTART.md`
- **Full Deployment Guide:** See `DEPLOYMENT.md`
- **API Documentation:** `https://your-backend-url.com/docs`
- **Contributing:** See `CONTRIBUTING.md`

---

## Emergency Contacts

- **Database Issues:** Check provider status page
- **Application Errors:** Review `backend/logs/app.log`
- **Performance Issues:** Check resource usage in dashboard

---

**Last Updated:** 2026-02-04
**Version:** 1.0.0
